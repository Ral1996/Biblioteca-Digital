<?php

//Invocamos la SESSION.
session_start();
if(!isset($_SESSION["Admin"])) // Sí la sesión es diferente de "Admin" se le redireccionará a el LOGIN.
{
    echo "<script>location.replace('index.php');</script>";
}
// Incluimos los archivos de CONEXIÓN.
include_once("db.php");
include_once("conexion.php"); 

?>

<!DOCTYPE html>
<html class="no-js" lang="es">
<head>
    <?php include "head.php"; ?>
</head>
<body>

    <?php include "left_menu.php"; ?>
    
    <!-- Right Panel -->

    <div id="right-panel" class="right-panel">

        <?php include "top_menu.php"; ?>
        <div class="breadcrumbs">
            <div class="col-sm-12">
                <div class="page-header float-left">
                    <div class="page-title">
                        <h1>Administrar Usuarios</h1>
                    </div>
                </div>
            </div>
        </div>

        <div class="content mt-3"> <!-- .content -->

            
            <div class="row">

              <div class="col-lg-12">
                    <div class="card">
                      <div class="card-header">
                        <strong>Agregar nuevo usuario!</strong> 
                      </div>
                      <div class="card-body card-block">
                           
                            <?php
                                if($_SESSION["Admin"]=="Admin")
                                {
                                    
                            ?>
                            <form class="form-horizontal" method="POST" action="" enctype="multipart/form-data">
                                
                                <div class="form-group col-sm-6">
                                    <label class="form-control-label" for="state-success">Nombre:</label>
                                        <input type="text" class="form-control" id="name_usuario" name="name_usuario" placeholder="Ligth Yagami" required>
                                </div>

                                <div class="form-group col-sm-6">
                                    <label class="form-control-label" for="state-success">Dirección:</label>
                                        <input type="text" class="form-control" id="direccion_user" name="direccion_user" placeholder="Los alamos, okinawa" required>
                                </div>

                                <div class="form-group col-sm-4">
                                    <label class="form-control-label" for="state-success">Teléfono:</label>
                                        <input type="text" class="form-control" id="telefono_user" name="telefono_user" placeholder="7785-9977" required>
                                </div>

                                <div class="form-group col-sm-4">
                                    <label class="form-control-label" for="state-success">Correo:</label>
                                        <input type="email" class="form-control" id="correo_user" name="correo_user" placeholder="algo_2018@gmail.com" required>
                                </div>

                                <div class="form-group col-sm-4">
                                    <label class="form-control-label" for="state-success">Cargo:</label>
                                        <input type="text" class="form-control" id="cargo_user" name="cargo_user" placeholder="Auditor de Sistema" required>
                                </div>

                                <div class="form-group col-sm-3">
                                    <label class="form-control-label" for="state-success">Usuario:</label>
                                        <input type="text" class="form-control" id="name_user" name="name_user" placeholder="Bran9722" required>
                                </div>

                                 <div class="form-group col-sm-3">
                                    <label class="form-control-label" for="state-success">Contraseña:</label>
                                        <input type="password" class="form-control" id="pass_user" name="pass_user" placeholder="********7" required>
                                </div>

                                <div class="form-group col-sm-3" id="centrar">
                                    <label class="form-control-label" for="state-success">Permiso:</label>
                                        <select class="select form-control" name="tipo_user" id="tipo_user" required>
                                            <option value=''>Seleccione..</option>
                                            <?php 
                                              $consulta_tipo_user = mysqli_query($con,"SELECT * FROM permisos");
                                              while($fila = mysqli_fetch_array($consulta_tipo_user)){

                                                echo "<option value='".$fila['id_permiso']."'>".$fila['permiso']."</option>";

                                                     }
                                            ?>
                                        </select>
                                </div>

                                <div class="form-group col-sm-3" id="centrar">
                                    <label class="form-control-label" for="state-success">Estado:</label>
                                        <select class="select form-control" name="estado_user" id="estado_user" required>
                                            <option value=''>Seleccione..</option>
                                            <?php 
                                              $estado = array('ACTIVO','INACTIVO','VETADO');
                                              $array = $estado;
                                              for ($k=0; $k<sizeof($array); $k++)
                                              {
                                                echo "<option value='$array[$k]'>". $array[$k] . "</option>";
                                              }
                                            ?>
                                        </select> 
                                </div>

                                <div class="form-actions">
                                    <div class="col-sm-offset-3 col-sm-9">
                                        <button class="btn btn-icon btn-primary" type="submit" id="submit" name="submit"><i class="fa fa-lock"></i>&nbsp;Guardar</button>
                                        <a class="btn btn-success" href="admin_Configuracion.php"><i class="fa fa-reply"></i> Regresar</a>
                                    </div>
                                </div>

                            </form> 
                            <?php
                                }
                                else
                                {
                                    echo "<br><br><div class='alert alert-danger'>No posee permisos para este modulo</div>";
                                }
                            ?>  
                        </div>
                    </div>
                </div>
            </div>

        </div> <!-- .content -->
    </div><!-- End right-panel -->

    <!-- End Right Panel -->

    <?php include "scripts.php"; ?>
    <!-- SweetAlert2 -->
    <script type="text/javascript" src="assets/js/sweetalert2.all.js"></script>
    <!-- Optional: include a polyfill for ES6 Promises for IE11 and Android browser -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/core-js/2.4.1/core.js"></script>


</body>
</html>

<?php 

if (isset($_POST['submit'])){

  $nameUsuario = $_POST["name_usuario"];
  $direccionUser = $_POST["direccion_user"];
  $telefonoUser = $_POST['telefono_user'];
  $correoUser = $_POST["correo_user"];
  $cargoUser = $_POST['cargo_user'];
  $nameUser = $_POST["name_user"];
  $passUser = MD5($_POST['pass_user']);
  $typeUser = $_POST['tipo_user'];
  $estatusEstudiante = $_POST['estado_user'];

  if ($nameUsuario == "" && $direccionUser == "" && $telefonoUser == "" && $correoUser = "")
  {
    echo "
            <script>
                swal({
                  type: 'error',
                  title: 'Se ha producido un error!',
                  text: 'Complete el formulario!',
                })
            </script>"; 
  }
  else{

      $sql_comprueba_user = "SELECT * FROM usuarios WHERE name_usu = '$nameUsuario'";
      $ejecuta_sql_user = mysqli_query($con,$sql_comprueba_user);
      $comprueba_user = mysqli_num_rows($ejecuta_sql_user);
      if($comprueba_user == 0)
      {
          $insertar_user = mysqli_query($con,
                                          "INSERT INTO usuarios (
                                                       id_usu,
                                                       name_usu,
                                                       direc_usu,
                                                       tell_usu,
                                                       email_usu,
                                                       cargo_usu,
                                                       name_user,
                                                       pass_user,
                                                       permiso_usu,
                                                       activo_user) 
                                          values(null, '$nameUsuario',
                                                       '$direccionUser',
                                                       '$telefonoUser',
                                                       '$correoUser',
                                                       '$cargoUser',
                                                       '$nameUser',
                                                       '$passUser',
                                                       '$typeUser',
                                                       '$estatusEstudiante')

                                          ");
          if($insertar_user)
          {
              echo "
                <script>
                    swal({
                      type: 'success',
                      title: 'Acción procesada con éxito!',
                      text: 'El usuario se guardo con éxito!',
                    })
                </script>";     
                 
          }else
          {
              echo "
                <script>
                    swal({
                      type: 'error',
                      title: 'Se ha producido un error!',
                      text: 'No se pudo guardar el usuario!',
                    })
                </script>";  
          }
       }
       else
       {
           echo "
                <script>
                    swal({
                      type: 'error',
                      title: 'Se ha producido un error!',
                      text: 'El usuario ya existe!',
                    })
                </script>"; 
          // mysqli_close($con);
       }
   }     
}
?>  