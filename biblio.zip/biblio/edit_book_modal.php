<?php
// INVOCAMOS LA SESSION.
session_start();

function initial(){  
include_once("db.php");
include_once("conexion.php");

if(!isset($_SESSION["Admin"]))
{
    echo "<script>location.replace('index.php');</script>";
}

?>
<div class="modal-header">
		<h4 class="modal-title">Detalle de Libros</h4>
	<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
</div>
<div class="modal-body col-lg-12">
	<?php
		if($_SESSION["Admin"] == "Admin" || $_SESSION["Admin"] == "Personal_Admin")
        {

			// CREAMOS CONSULTAS PARA MOSTRAR DATOS RELEVANTES EN LA TABLA-MODAL.    	
			$id_bookX = $_REQUEST['id_book'];
			$consulta_libros = mysqli_query($con,"SELECT * FROM libros WHERE id_book = '$id_bookX'");
			$datos = mysqli_fetch_array($consulta_libros);
            $name_bookX = $datos['name_book'];
            //$cat_id = $datos['category_id'];	//RELATIONSHIPS
            //$edit_id = $datos['editorial_id'];  //RELATIONSHIPS	
		    $autor_bookX = $datos['name_author'];
		    $copy_bookX = $datos['copys_book'];
		    $pub_bookX = $datos['book_pub'];
		    $isbn_bookX = $datos['isbn'];
		    $year_bookX = $datos['copy_year'];
		    $status_bookX = $datos['status_book'];
	?>
	<div class="wrapper wrapper-content animated fadeInRight">
		<div class="row" id="row1">
			<div class="col-lg-12">

				<form class="form-horizontal" method="POST" action="" enctype="multipart/form-data">
                                
                    <div class="form-group col-sm-5">
                        <label class="form-control-label" for="state-success">Libro:</label>
                            <input type="text" class="form-control" id="name_book" name="name_book" placeholder="El viejo y el mar" required value="<?php echo $name_bookX; ?>">
                    </div>

                    <div class="form-group col-sm-3" id="centrar">
                        <label class="form-control-label" for="state-success">Categoría:</label>
                        <select class="select form-control" name="cat_book" id="cat_book" required>
                            <option value=''>Seleccione..</option>
                            <?php 
                              $consulta_categoria_book = mysqli_query($con,"SELECT * FROM categorias");
                              while($filaz = mysqli_fetch_array($consulta_categoria_book)){

                                echo "<option value='".$filaz['id_category']."'>".$filaz['name_category']."</option>";

                                     }
                            ?>
                        </select>
                    </div>

                    <div class="form-group col-sm-4">
                        <label class="form-control-label" for="state-success">Autor:</label>
                            <input type="text" class="form-control" id="autor_book" name="autor_book" placeholder="Ernest Heminway" required value="<?php echo $autor_bookX; ?>">
                    </div>

                    <div class="form-group col-sm-2">
                        <label class="form-control-label" for="state-success">N° de copias:</label>
                            <input type="text" class="form-control" id="copy_book" name="copy_book" placeholder="100" required value="<?php echo $copy_bookX; ?>">
                    </div>

                    <div class="form-group col-sm-4">
                        <label class="form-control-label" for="state-success">Publicadora:</label>
                            <input type="text" class="form-control" id="pub_book" name="pub_book" placeholder="NOBEL ENTERTEIMENT" required value="<?php echo $pub_bookX; ?>">
                    </div>

                    <div class="form-group col-sm-3" id="centrar">
                        <label class="form-control-label" for="state-success">Editorial:</label>
                        <select class="select form-control" name="edit_book" id="edit_book" required>
                            <option value=''>Seleccione..</option>
                            <?php 
                              $consulta_editorial_book = mysqli_query($con,"SELECT * FROM editoriales");
                              while($filax = mysqli_fetch_array($consulta_editorial_book)){

                                echo "<option value='".$filax['id_editorial']."'>".$filax['name_editorial']."</option>";

                                     }
                            ?>
                        </select>
                    </div>

                    <div class="form-group col-sm-3">
                        <label class="form-control-label" for="state-success">ISBN:</label>
                            <input type="text" class="form-control" id="isbn_book" name="isbn_book" placeholder="1-85435-628-3" required value="<?php echo $isbn_bookX; ?>">
                    </div>

                    <div class="form-group col-sm-3">
                        <label class="form-control-label" for="state-success">Año de publicación:</label>
                            <input type="text" class="form-control" id="year_book" name="year_book" placeholder="1996" required value="<?php echo $year_bookX; ?>">
                    </div>

                    <div class="form-group col-sm-3" id="centrar">
                        <label class="form-control-label" for="state-success">Estado:</label>
                            <select class="select form-control" name="estado_book" id="estado_book" required>
                                <option value=''>Seleccione..</option>
                                <?php 
                                  $estado = array('ACTIVO','INACTIVO');
                                  $array = $estado;
                                  for ($k=0; $k<sizeof($array); $k++)
                                  {
                                    echo "<option value='$array[$k]'>". $array[$k] . "</option>";
                                  }
                                ?>
                            </select> 
                    </div>
                    <div class="form-group col-sm-6" id="centrar">
                        <label class="form-control-label" for="state-success">Departamento:</label>
                        <select class="select form-control" name="depa_book" id="depa_book" required>
                            <option value=''>Seleccione..</option>
                            <?php 
                              $consulta_depa_book = mysqli_query($con,"SELECT * FROM departamentos");
                              while($fila = mysqli_fetch_array($consulta_depa_book)){

                                echo "<option value='".$fila['id_department']."'>".$fila['name_department']."</option>";

                                     }
                            ?>
                        </select>
                    </div>

                </form> 
				
			</div>
		</div>
	</div>
<!-- SweetAlert2 -->
<script type="text/javascript" src="assets/js/sweetalert2.all.js"></script>
<!-- Optional: include a polyfill for ES6 Promises for IE11 and Android browser -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/core-js/2.4.1/core.js"></script>
<script type="text/javascript">
	
// Clean the modal form
	$(document).on('hidden.bs.modal', function(e) 
	{
		var target = $(e.target);
		target.removeData('bs.modal').find(".modal-content").html('');
	});
	$(document).on("click","#editar", function(){
		var id_books1 = $("#id_books1").val();
		var nameBook22 = $("#name_book").val();
		var catBook22 = $("#cat_book").val();
		var autorBook22 = $("#autor_book").val();
		var copyBook22 = $("#copy_book").val();
		var pubBook22 = $("#pub_book").val();
		var editBook22 = $("#edit_book").val();
		var isbnBook22 = $("#isbn_book").val();
		var yearBook22 = $("#year_book").val();
		var estado22 = $("#estado_book").val();
		var depa22 = $("#depa_book").val();
		$.ajax({
			type : "POST",
			url : "edit_book_modal.php",
			data: "process=edit&id="+id_books1+"&name="+nameBook22+"&cat="+catBook22+"&autor="+autorBook22+"&copys="+copyBook22+"&pub="+pubBook22+"&edit="+editBook22+"&isbnx="+isbnBook22+"&year="+yearBook22+"&estatus="+estado22+"&depa="+depa22 ,
	        dataType: "JSON",
			success : function(datax) {
				if(datax.info == "Ok")
				{
				    swal({
                      type: 'success',
                      title: 'Acción procesada con éxito!',
                      text: 'El libro se actualizo con éxito!',
                    });
                    setInterval("location.replace('admin_Libros.php');", 1500);
				}
				else
				{
		            swal({
                      type: 'error',
                      title: 'Se ha producido un error!',
                      text: 'El libro no pudo actualizarse!',
                    });
             	}
			}
		});
	});
</script>
			
		</div>
<div class="modal-footer">
<?php

echo "<button type='button' class='btn btn-danger' id='editar'><i class='fa fa-refresh'></i> Actualizar</button>
	  <button type='button' class='btn btn-success' data-dismiss='modal' id='salir'><i class='fa fa-reply-all'></i> Salir</button>
	  <input type='hidden' id='id_books1' value='".$id_bookX."'>
				  
</div><!--/modal-footer -->";	
		}

		else
		{
			echo "<div class='alert alert-warning'>Usted no tiene permiso para acceder a este modulo</div></div>";
		}

	}
?>


<?php

function editar()
{
	include_once("db.php");
	include_once("conexion.php");

  	$id = $_POST["id"];
	$nameBook22 = $_POST['name'];
	$catBook22 = $_POST['cat'];
    $authorBook22 = $_POST['autor'];
    $copiesBook22 = $_POST['copys'];
    $pubBook22 = $_POST['pub'];
    $editBook22 = $_POST["edit"];
    $isbnBook22 = $_POST['isbnx'];
    $yearBook22 = $_POST['year'];
    $estatusBook22 = $_POST['estatus'];
    $depaBook22 = $_POST['depa'];


	$edit = mysqli_query($con,
							  "UPDATE libros 
						       SET name_book ='$nameBook22',
							   category_id ='$catBook22',
							   name_author ='$authorBook22',
							   copys_book  ='$copiesBook22',
							   book_pub  ='$pubBook22',
							   editorial_id  ='$editBook22',
						  	   isbn ='$isbnBook22',
						   	   copy_year = '$yearBook22',
						   	   date_added = NOW(),
						   	   status_book = '$estatusBook22',
						   	   depa_id = '$depaBook22'  
							   WHERE id_book = '$id'"
						);
	if($edit)
	{
		$datos["info"] = "Ok";
	}	
	else
	{

		$datos["info"] = "No".mysqli_error();
	}
		echo json_encode($datos);
    }
	
if(!isset($_POST['process'])){
	initial(); 
}
else
{
if(isset($_POST['process'])){	
switch ($_POST['process']) {
	case 'edit':
    editar();
    break;	
	} 
}			
}
?>