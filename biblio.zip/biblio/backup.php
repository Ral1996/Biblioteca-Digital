<?php
 
 	$target = getcwd();
	$dbhost = "localhost";
	$dbname = "biblio";
	$dbuser = "root";
	$dbpwd = "79896680";

	$filename = str_replace(":", "", $dbname.date("d-m-YH:i").'.sql');
	$backup = $target."/".$filename;

	$command = "mysqldump -u $dbuser -p$dbpwd $dbname > $backup";

	shell_exec($command);
	header('Content-Type: application/octet-stream');
	header('Content-Transfer-Encoding: Binary');
	header('Content-Disposition: attachment; filename='.basename($backup));
	header('Content-Transfer-Encoding: binary');
	header('Content-Type: application/download');
	header('Content-Description: File Transfer');
	header('Content-Length: '.filesize($backup));
	readfile($backup);

	shell_exec("rm ".$backup);

	echo "<script>location.replace('admin_Mantenimiento.php');</script>";
?>
