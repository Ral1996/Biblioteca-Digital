<?php
// INVOCAMOS LA SESSION.
session_start();

function initial(){  
include_once("db.php");
include_once("conexion.php");

if(!isset($_SESSION["Admin"]))
{
    echo "<script>location.replace('index.php');</script>";
}

?>
<div class="modal-header">
		<h4 class="modal-title">Detalle de Editoriales</h4>
	<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
</div>
<div class="modal-body">
	<?php
		if($_SESSION["Admin"] == "Admin" || $_SESSION["Admin"] == "Personal_Admin")                       
        {

			// CREAMOS CONSULTAS PARA MOSTRAR DATOS RELEVANTES EN LA TABLA-MODAL.    	
			$id_editorial = $_REQUEST['id_editorial'];
			$consulta_Editorial = mysqli_query($con,"SELECT * FROM editoriales WHERE id_editorial = '$id_editorial'");
			$datos = mysqli_fetch_array($consulta_Editorial);
            $name_Editorial = $datos["name_editorial"];
	?>
	<div class="wrapper wrapper-content animated fadeInRight">
		<div class="row" id="row1">
			<div class="col-lg-12">

				<form class="form-horizontal" method="POST"">
                                
                    <div class="form-group">
                        <label class="form-control-label" for="state-success">Editorial:</label>
                            <input type="text" class="form-control" id="nameEdit1" name="nameEdit1" placeholder="Ciencia ficción, Terror, Romance, Suspenso, Belico." value="<?php echo $name_Editorial; ?>">
                    </div>
                    <div class="form-group">
                        <label class="form-control-label" for="state-success">Estado:</label>
                        <select class="select form-control" name="estado" id="estado">
                        	<?php 
                        		$estado = array('ACTIVO','INACTIVO');
							    $array = $estado;
							    for ($i=0; $i<sizeof($array); $i++)
							  	{
							  		echo "<option value='$array[$i]'>". $array[$i] . "</option>";
							  	}
                        	?>
                        </select>
                        
                    </div>
                     
                </form> 
				
			</div>
		</div>
	</div>
<!-- SweetAlert2 -->
<script type="text/javascript" src="assets/js/sweetalert2.all.js"></script>
<!-- Optional: include a polyfill for ES6 Promises for IE11 and Android browser -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/core-js/2.4.1/core.js"></script>
<script type="text/javascript">
	
// Clean the modal form
	$(document).on('hidden.bs.modal', function(e) 
	{
		var target = $(e.target);
		target.removeData('bs.modal').find(".modal-content").html('');
	});
	$(document).on("click","#editar", function(){
		var id_editorial1 = $("#id_editorial1").val();
		var nameEdit22 = $("#nameEdit1").val();
		var estado22 = $("#estado").val();
		$.ajax({
			type : "POST",
			url : "edit_editorial_modal.php",
			data: "process=edit&id="+id_editorial1+"&name="+nameEdit22+"&estatus="+estado22 ,
	        dataType: "JSON",
			success : function(datax) {
				if(datax.info == "Ok")
				{
				    swal({
                      type: 'success',
                      title: 'Acción procesada con éxito!',
                      text: 'La editorial se actualizo con éxito!',
                    });
                    setInterval("location.replace('admin_Editoriales.php');", 1500);
				}
				else
				{
		            swal({
                      type: 'error',
                      title: 'Se ha producido un error!',
                      text: 'La editorial no pudo actualizarse!',
                    });
             	}
			}
		});
	});
</script>
			
		</div>
<div class="modal-footer">
<?php

echo "<button type='button' class='btn btn-danger' id='editar'><i class='fa fa-refresh'></i> Actualizar</button>
	  <button type='button' class='btn btn-success' data-dismiss='modal' id='salir'><i class='fa fa-reply-all'></i> Salir</button>
	  <input type='hidden' id='id_editorial1' value='".$id_editorial."'>
				  
</div><!--/modal-footer -->";	
		}

		else
		{
			echo "<div class='alert alert-warning'>Usted no tiene permiso para acceder a este modulo</div></div>";
		}

	}
?>


<?php

function editar()
{
	include_once("db.php");
	include_once("conexion.php");

	$id = $_POST["id"];
	$nameEditorial2 = $_POST["name"];
  	$statusEditorial2 = $_POST["estatus"];
	$edit = mysqli_query($con,
							  "UPDATE editoriales 
							   SET name_editorial ='$nameEditorial2',
							   	   activo = '$statusEditorial2' 
							   WHERE id_editorial = '$id'"
						);
	if($edit)
	{
		$datos["info"] = "Ok";
	}	
	else
	{

		$datos["info"] = "No".mysqli_error();
	}
	echo json_encode($datos);
}
	
if(!isset($_POST['process'])){
	initial(); 
}
else
{
if(isset($_POST['process'])){	
switch ($_POST['process']) {
	case 'edit':
    editar();
    break;	
	} 
}			
}
?>