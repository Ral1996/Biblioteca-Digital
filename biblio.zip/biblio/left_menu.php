<!-- Left Panel -->

<aside id="left-panel" class="left-panel">
    <nav class="navbar navbar-expand-sm navbar-default">

        <div class="navbar-header">
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#main-menu" aria-controls="main-menu" aria-expanded="false" aria-label="Toggle navigation">
                <i class="fa fa-bars"></i>
            </button>
            <a class="navbar-brand" href="admin_Dashboard.php">Digital Library</a>
            <a class="navbar-brand hidden" href="admin_Dashboard.php">DL</a>
        </div>

        <div id="main-menu" class="main-menu collapse navbar-collapse">
            <ul class="nav navbar-nav">
                <h3 class="menu-title">Menú de operaciones...</h3><!-- /.menu-title -->
                <li class="active">
                    <a href="admin_Dashboard.php"> <i class="menu-icon fa fa-desktop"></i>Dashboard </a>
                </li>
                <li class="">
                    <a href="admin_Administrar.php"> <i class="menu-icon fa fa-home"></i>Administrar </a>
                </li>
                <li class="">
                    <a href="admin_Estudiante.php"> <i class="menu-icon fa fa-users"></i>Miembros </a>
                </li>
                <li class="menu-item-has-children dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <i class="menu-icon fa fa-book"></i>Libros</a>
                    <ul class="sub-menu children dropdown-menu">
                        <li><i class="menu-icon fa fa-tags"></i><a href="admin_Libros.php">Libro</a></li>
                        <li><i class="menu-icon fa fa-tags"></i><a href="admin_Categorias.php">Categoría</a></li>
                        <li><i class="menu-icon fa fa-tags"></i><a href="admin_Editoriales.php">Editorial</a></li>
                    </ul>
                </li>
                <li class="menu-item-has-children dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <i class="menu-icon fa fa-edit"></i>Acciones diversas </a>
                    <ul class="sub-menu children dropdown-menu">
                        <li><i class="menu-icon fa fa-tags"></i><a href="admin_PrestarL.php">Prestar libro</a></li>
                        <li><i class="menu-icon fa fa-tags"></i><a href="admin_Prestamos.php">Prestamos</a></li>
                    </ul>
                </li>
                <?php if($_SESSION["Admin"] == "Admin") {?>
                <li class="">
                    <a href="admin_Configuracion.php"> <i class="menu-icon fa fa-gear"></i>Configuraciones </a>
                </li>
                <?php } ?>
                <li class="">
                    <a href="admin_Mantenimiento.php"> <i class="menu-icon fa fa-wrench"></i>Mantenimiento </a>
                </li>
                <li class="">
                    <a href="admin_Developers.php"> <i class="menu-icon fa fa-linux"></i>Desarrolladores </a>
                </li>
            </ul>
        </div><!-- /.navbar-collapse -->
    </nav>
</aside><!-- /#left-panel -->

<!-- Left Panel -->
