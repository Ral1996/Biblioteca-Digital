<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Bootstrap Material Admin by Bootstrapious.com</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="all,follow">
    <!-- Bootstrap CSS-->
    <link rel="stylesheet" href="others/vendor/bootstrap/css/bootstrap.min.css">
    <!-- Fontastic Custom icon font-->
    <link rel="stylesheet" href="others/css/fontastic.css">
    <!-- Font Awesome CSS-->
    <link rel="stylesheet" href="others/vendor/font-awesome/css/font-awesome.min.css">
    <!-- Google fonts - Poppins -->
    <link rel="stylesheet" href="others/https://fonts.googleapis.com/css?family=Poppins:300,400,700">
    <!-- theme stylesheet-->
    <link rel="stylesheet" href="others/css/style.default.css" id="theme-stylesheet">
    <!-- Custom stylesheet - for your changes-->
    <link rel="stylesheet" href="others/css/custom.css">
    <!-- Favicon-->
    <link rel="shortcut icon" href="favicon.png">
    <style type="text/css">
        .login-page
        {
            background: url('assets/images/b2.jpg');
        }
    </style>
  </head>
  <body>
    <div class="page login-page">
      <div class="container d-flex align-items-center">
        <div class="form-holder has-shadow">
          <div class="row">
            <!-- Logo & Information Panel-->
            <div class="col-lg-6">
              <div class="info d-flex align-items-center">
                <div class="content">
                  <div class="logo">
                    <h1>Digital Library</h1>
                  </div>
                  <p>Bienvenidos al apartado de registro de usuarios.</p>
                </div>
              </div>
            </div>
            <!-- Form Panel    -->
            <div class="col-lg-6 bg-white">
              <div class="form d-flex align-items-center">
                <div class="content">
                  <form id="register-form">
                    <div class="form-group">
                      <input id="register-username" type="text" name="registerUsername" required class="input-material">
                      <label for="register-username" class="label-material">Nombre usuario</label>
                    </div>
                    <div class="form-group">
                      <input id="register-email" type="email" name="registerEmail" required class="input-material">
                      <label for="register-email" class="label-material">Correo electronico      </label>
                    </div>
                    <div class="form-group">
                      <input id="register-passowrd" type="password" name="registerPassword" required class="input-material">
                      <label for="register-passowrd" class="label-material">Contraseña        </label>
                    </div>
                    <div class="form-group terms-conditions">
                      <input id="license" type="checkbox" required class="checkbox-template">
                      <label for="license">Acepta los términos y condiciones.</label>
                    </div>
                    <input id="register" type="submit" value="Register" class="btn btn-info">
                  </form><small>Ya tienes una cuenta? </small><a href="index.php" class="signup">Login</a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="copyrights text-center">
        <p>Design by <a href="javascript:void(0);" class="external">RED - PortillO's</a></p>
      </div>
    </div>
    <!-- Javascript files-->
    <script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
    <script src="others/vendor/popper.js/umd/popper.min.js"> </script>
    <script src="others/vendor/bootstrap/js/bootstrap.min.js"></script>
    <script src="others/vendor/jquery.cookie/jquery.cookie.js"> </script>
    <script src="others/vendor/jquery-validation/jquery.validate.min.js"></script>
    <script src="others/js/front.js"></script>
  </body>
</html>