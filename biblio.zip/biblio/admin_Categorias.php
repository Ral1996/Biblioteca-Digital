<?php

//Invocamos la SESSION.
session_start();
// Incluimos los archivos de CONEXIÓN.
include_once("db.php");
include_once("conexion.php");

if(!isset($_SESSION["Admin"])) // Sí la sesión es diferente de "Admin" se le redireccionará a el LOGIN.
{
    echo "<script>location.replace('index.php');</script>";
}
    

?>

<!DOCTYPE html>
<html class="no-js" lang="es">
<head>
    <?php include "head.php"; ?>
</head>
<body>

    <?php include "left_menu.php"; ?>
    
    <!-- Right Panel -->

    <div id="right-panel" class="right-panel">

        <?php include "top_menu.php"; ?>
        
        <div class="content mt-3"> <!-- .content -->

            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-inverse panel-border">
                        <div class="panel-heading">
                            <!--<h3 class="panel-title">Administrar Departamentos</h3>-->
                        </div>
                        <div class="panel-body">
                            <a class="btn btn-success" href="add_Categoria.php"><i class="fa fa-plus-square"></i> Agregar categoría</a>
                            <br>
                            <?php
                                if($_SESSION["Admin"] == "Admin" || $_SESSION["Admin"] == "Personal_Admin")
                                {
                                    $quey_categoria = mysqli_query($con,"SELECT * FROM categorias") or die(mysqli_error());       
                            ?>
                            <br>
                            <div class="col-md-12">
                               
                                <table class="table table-striped table-bordered" >
                                    <thead>
                                        <tr class="table-success">
                                            <th class="col-sm-1">N°</th>
                                            <th class="col-sm-7">Categorías</th>
                                            <th class="col-sm-2">Estado</th>
                                            <th class="col-sm-2">Acciones</th>
                                        </tr>
                                    </thead>
                                    <tbody>

                                    <?php
                                        
                                        $i=1;
                                        while ($row = mysqli_fetch_array($quey_categoria))
                                        {
                                            $id = $row['id_category']; 
                                            //$idDepa = $row["id_department"];
                                            //$nombreDepa = $row["name_department"];
                                            //$i++;
                                            $activo = $row['activo'];
                                    ?>
                                    <tr>   
                                        <td><?php echo $i;?></td>
                                        <td><?php echo $row['name_category'];?></td>
                                        <?php 
                                            if($row['activo'] == "ACTIVO")
                                            {
                                                echo "<td><font color='green'>".$activo."</font></td>";
                                            }else if($row['activo'] == "INACTIVO")
                                            {
                                                echo "<td><font color='red'>".$activo."</font></td>";
                                            }else
                                            {
                                                echo "<td>".$activo."</td>";
                                            }
                                        ?>
                                        
                                        <td width="100">
                                            <a style="margin-left:20%;" data-toggle ='modal' data-target = "#viewModalA" data-refresh = "true" title = "Editar Categoría" href="edit_category_modal.php?id_category=<?php echo $id;?>"><i class="fa fa-pencil"></i></a>
                                            <?php if($_SESSION["Admin"] == "Admin") { ?>
                                            <a class="elim" data-toggle ='modal' data-target = "#viewModalB" data-refresh = "true"  href="delete_category_modal.php?id_category=<?php echo $id;?>" id="" title="Eliminar Categoría"><i class="fa fa-trash" style="margin-left:20%;"></i></a>
                                            <?php } ?>
                                        </td>
                                    </tr>
                                    <?php
                                        $i = $i+1;
                                        } 
                                    ?>
                                    </tbody>
                                </table> 
                            
                            </div>
                            <?php
                                }
                                else
                                {
                                    echo "<br><br><div class='alert alert-danger'>No posee permisos para este modulo</div>";
                                }
                            ?>
                        </div>
                    </div>
                </div>
            </div>

            <!--Show Modal Popups View & Delete -->
            <div class='modal fade' id='viewModalB' tabindex='-1' role='dialog' aria-labelledby='myModalLabel' aria-hidden='true'>
                <div class='modal-dialog'>
                    <div class='modal-content modal-lg'></div><!-- /.modal-content -->
                </div><!-- /.modal-dialog -->
            </div><!-- /.modal -->  
            <!--Show Modal Popups View & Edit -->
            <div class='modal fade' id='viewModalA' tabindex='-1' role='dialog' aria-labelledby='myModalLabel' aria-hidden='true'>
                <div class='modal-dialog'>
                    <div class='modal-content modal-lg'></div><!-- /.modal-content -->
                </div><!-- /.modal-dialog -->
            </div><!-- /.modal -->  


        </div> <!-- .content -->
    </div><!-- End right-panel -->

    <!-- End Right Panel -->

    <?php include "scripts.php"; ?>
    <script type="text/javascript">
    
        $(".table").DataTable(
            {
            "iDisplayLength": 5 ,
            "language":{
                "sProcessing":     "Procesando...",
                "sLengthMenu":     "Mostrar _MENU_ registros",
                "sZeroRecords":    "No se encontraron resultados",
                "sEmptyTable":     "Ningún dato disponible en esta tabla",
                "sInfo":           "Mostrando registros del _START_ al _END_ de un total de _TOTAL_ registros",
                "sInfoEmpty":      "Mostrando registros del 0 al 0 de un total de 0 registros",
                "sInfoFiltered":   "(filtrado de un total de _MAX_ registros)",
                "sInfoPostFix":    "",
                "sSearch":         "Buscar:",
                "sUrl":            "",
                "sInfoThousands":  ",",
                "sLoadingRecords": "Cargando...",
                "oPaginate": {
                    "sFirst":    "Primero",
                    "sLast":     "Último",
                    "sNext":     "Siguiente",
                    "sPrevious": "Anterior"
                },
                "oAria": {
                    "sSortAscending":  ": Activar para ordenar la columna de manera ascendente",
                    "sSortDescending": ": Activar para ordenar la columna de manera descendente"
                }
            }
        });
    
    </script>
    <script type="text/javascript">
    $(document).on('hidden.bs.modal', function(e) 
    {
        var target = $(e.target);
        target.removeData('bs.modal').find(".modal-content").html('');
    });
    </script>
    </body>
</html>

