<?php
// INVOCAMOS LA SESSION.
session_start();

function initial(){  
include_once("db.php");
include_once("conexion.php");

if(!isset($_SESSION["Admin"]))
{
    echo "<script>location.replace('index.php');</script>";
}

?>
<div class="modal-header">
		<h4 class="modal-title">Detalle de Usuarios</h4>
	<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
</div>
<div class="modal-body col-lg-12">
	<?php
		if($_SESSION["Admin"] == "Admin"){

			// CREAMOS CONSULTAS PARA MOSTRAR DATOS RELEVANTES EN LA TABLA-MODAL.    	
			$id_user = $_REQUEST['id_usu'];
			$consulta_usuarios = mysqli_query($con,"SELECT * FROM usuarios WHERE id_usu = '$id_user'");
			$datos = mysqli_fetch_array($consulta_usuarios);
            $name_usuario = $datos['name_usu'];
            $direc_usuario = $datos['direc_usu'];
		    $tell_usuario = $datos['tell_usu'];
		    $email_usuario = $datos['email_usu'];
		    $cargo_usuario = $datos['cargo_usu'];
		    $namex_usuario = $datos['name_user'];
		    //$pass_usuario = $datos['pass_user'];
		    //$permiso_usuario = $datos['permiso_usu'];
		    //$estatus_usuario = $datos['activo_usu'];
	?>
	<div class="wrapper wrapper-content animated fadeInRight">
		<div class="row" id="row1">
			<div class="col-lg-12">

				<form class="form-horizontal" method="POST"">
                
	                <div class="form-group col-sm-6">
                    <label class="form-control-label" for="state-success">Nombre:</label>
                        <input type="text" class="form-control" id="name_usuario" name="name_usuario" placeholder="Ligth Yagami" required value="<?php echo $name_usuario; ?>">
                    </div>

                    <div class="form-group col-sm-6">
                        <label class="form-control-label" for="state-success">Dirección:</label>
                            <input type="text" class="form-control" id="direccion_user" name="direccion_user" placeholder="Los alamos, okinawa" required value="<?php echo $direc_usuario; ?>">
                    </div>

                    <div class="form-group col-sm-4">
                        <label class="form-control-label" for="state-success">Teléfono:</label>
                            <input type="text" class="form-control" id="telefono_user" name="telefono_user" placeholder="7785-9977" required value="<?php echo $tell_usuario; ?>">
                    </div>

                    <div class="form-group col-sm-4">
                        <label class="form-control-label" for="state-success">Correo:</label>
                            <input type="email" class="form-control" id="correo_user" name="correo_user" placeholder="algo_2018@gmail.com" required value="<?php echo $email_usuario; ?>">
                    </div>

                    <div class="form-group col-sm-4">
                        <label class="form-control-label" for="state-success">Cargo:</label>
                            <input type="text" class="form-control" id="cargo_user" name="cargo_user" placeholder="Auditor de Sistema" required value="<?php echo $cargo_usuario; ?>">
                    </div>

                    <div class="form-group col-sm-3">
                        <label class="form-control-label" for="state-success">Usuario:</label>
                            <input type="text" class="form-control" id="name_user" name="name_user" placeholder="Bran9722" required value="<?php echo $namex_usuario; ?>">
                    </div>

                     <div class="form-group col-sm-3">
                        <label class="form-control-label" for="state-success">Contraseña:</label>
                            <input type="password" class="form-control" id="pass_user" name="pass_user" placeholder="********7" required>
                    </div>

                    <div class="form-group col-sm-3" id="centrar">
                        <label class="form-control-label" for="state-success">Permiso:</label>
                            <select class="select form-control" name="tipo_user" id="tipo_user" required>
                                <option value=''>Seleccione..</option>
                                <?php 
                                  $consulta_tipo_user = mysqli_query($con,"SELECT * FROM permisos");
                                  while($fila = mysqli_fetch_array($consulta_tipo_user)){

                                    echo "<option value='".$fila['id_permiso']."'>".$fila['permiso']."</option>";

                                         }
                                ?>
                            </select>
                    </div>

                    <div class="form-group col-sm-3" id="centrar">
                        <label class="form-control-label" for="state-success">Estado:</label>
                            <select class="select form-control" name="estado_user" id="estado_user" required>
                                <option value=''>Seleccione..</option>
                                <?php 
                                  $estado = array('ACTIVO','INACTIVO','VETADO');
                                  $array = $estado;
                                  for ($k=0; $k<sizeof($array); $k++)
                                  {
                                    echo "<option value='$array[$k]'>". $array[$k] . "</option>";
                                  }
                                ?>
                            </select> 
                    </div>

                </form> 
				
			</div>
		</div>
	</div>
<!-- SweetAlert2 -->
<script type="text/javascript" src="assets/js/sweetalert2.all.js"></script>
<!-- Optional: include a polyfill for ES6 Promises for IE11 and Android browser -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/core-js/2.4.1/core.js"></script>
<script type="text/javascript">
	
// Clean the modal form
	$(document).on('hidden.bs.modal', function(e) 
	{
		var target = $(e.target);
		target.removeData('bs.modal').find(".modal-content").html('');
	});
	$(document).on("click","#editar", function(){
		var id_user1 = $("#id_user1").val();
		var nameUser22 = $("#name_usuario").val();
		var direcUser22 = $("#direccion_user").val();
		var tellUser22 = $("#telefono_user").val();
		var emailUser22 = $("#correo_user").val();
		var cargoUser22 = $("#cargo_user").val();
		var user22 = $("#name_user").val();
		var pass22 = $("#pass_user").val();
		var permisoUser22 = $("#tipo_user").val();
		var estado22 = $("#estado_user").val();
		$.ajax({
			type : "POST",
			url : "edit_user_modal.php",
			data: "process=edit&id="+id_user1+"&name="+nameUser22+"&direc="+direcUser22+"&tel="+tellUser22+"&correos="+emailUser22+"&cargo="+cargoUser22+"&user="+user22+"&pass="+pass22+"&permi="+permisoUser22+"&estatus="+estado22 ,
	        dataType: "JSON",
			success : function(datax) {
				if(datax.info == "Ok")
				{
				    swal({
                      type: 'success',
                      title: 'Acción procesada con éxito!',
                      text: 'El usuario se actualizo con éxito!',
                    });
                    setInterval("location.replace('admin_Configuracion.php');", 1500);
				}
				else
				{
		            swal({
                      type: 'error',
                      title: 'Se ha producido un error!',
                      text: 'El usuario no pudo actualizarse!',
                    });
             	}
			}
		});
	});
</script>
			
		</div>
<div class="modal-footer">
<?php

echo "<button type='button' class='btn btn-danger' id='editar'><i class='fa fa-refresh'></i> Actualizar</button>
	  <button type='button' class='btn btn-success' data-dismiss='modal' id='salir'><i class='fa fa-reply-all'></i> Salir</button>
	  <input type='hidden' id='id_user1' value='".$id_user."'>
				  
</div><!--/modal-footer -->";	
		}

		else
		{
			echo "<div class='alert alert-warning'>Usted no tiene permiso para acceder a este modulo</div></div>";
		}

	}
?>


<?php

function editar()
{
	include_once("db.php");
	include_once("conexion.php");

  	$id = $_POST["id"];
	$nameUsuario22 = $_POST['name'];
	$direccionUsuario22 = $_POST['direc'];
    $telefonoUsuario22 = $_POST['tel'];
    $correoUsuario22 = $_POST['correos'];
    $cargoUsuario22 = $_POST['cargo'];
    $namexUsuario22 = $_POST["user"];
    $passUsuario22 = MD5($_POST['pass']);
    $permisoUsuario22 = $_POST['permi'];
    $estatusUsuario22 = $_POST['estatus'];


	$edit = mysqli_query($con,
							  "UPDATE usuarios 
						       SET name_usu ='$nameUsuario22',
							   direc_usu ='$direccionUsuario22',
							   tell_usu ='$telefonoUsuario22',
							   email_usu ='$correoUsuario22',
							   cargo_usu ='$cargoUsuario22',
							   name_user ='$namexUsuario22',
						  	   pass_user ='$passUsuario22',
						   	   permiso_usu = '$permisoUsuario22',
						   	   activo_user = '$estatusUsuario22'  
							   WHERE id_usu = '$id'"
						);
	if($edit)
	{
		$datos["info"] = "Ok";
	}	
	else
	{

		$datos["info"] = "No".mysqli_error();
	}
		echo json_encode($datos);
    }
	
if(!isset($_POST['process'])){
	initial(); 
}
else
{
if(isset($_POST['process'])){	
switch ($_POST['process']) {
	case 'edit':
    editar();
    break;	
	} 
}			
}
?>