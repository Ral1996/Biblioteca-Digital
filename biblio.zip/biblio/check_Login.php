<?php	
 if($_POST) //Comprobamos si se envián variables desde el form por el método POST
  {
    $nameUsuario = $_POST["loginUsername"]; //Capturamos lo digitado por el usuario en la caja de texto del correo de usuario
    $contraUsuario = MD5($_POST["loginPassword"]); //Capturamos lo digitado por el usuario en la caja de texto de nombre clave
    $sql_user = "SELECT * FROM usuarios WHERE name_user = '$nameUsuario'";
    $consulta = mysqli_query($con,$sql_user); //Ejecuto la consulta y la almaceno en una variable
    $tipo = mysqli_fetch_array($consulta);
    $contar=mysqli_num_rows($consulta); //Verifico si la consulta devuelve alguna fila 
    if($contar > 0) //Si devuelve alguna fila le permitimos el acceso
    {
        if($tipo["pass_user"] == $contraUsuario)
        {
            if($tipo["permiso_usu"] == 1)
            {
               $_SESSION["Admin"] = "Admin";
               echo "<script>location.replace('admin_Dashboard.php');</script>"; //
            } elseif ($tipo["permiso_usu"] == 2) {
                $_SESSION["Admin"] = "Personal_Admin";
                echo"<script>location.replace('admin_Dashboard.php');</script>"; //
            } elseif ($tipo["permiso_usu"] == 3) {
                $_SESSION["Admin"] = "Docente";
                echo"<script>location.replace('docente_Dashboard.php');</script>"; //
            }else{
                $_SESSION["Admin"]="Estudiante";
                echo"<script>location.replace('estudiante_Dashboard.php');</script>"; //
            }

            $_SESSION["usu"] = $tipo["id_usu"];
            $_SESSION["name"] = $tipo["name_usu"];
            $_SESSION["direc"] = $tipo["direc_usu"];
            $_SESSION["tel"] = $tipo["tell_usu"];
            $_SESSION["correox"] = $tipo["email_usu"];
            $_SESSION["user"] = $tipo["name_user"];
            $_SESSION["cargo"] = $tipo["cargo_usu"];
            
           
            mysqli_close($con); //cerramos conexion con la base de datos 
        }
        else
        {  
            echo "<script>alertaContra();</script>"; //arroja un mensaje de error si la contraseña es incorrecta.
            
        }
    }
    else
    {
      echo "<script>alertaUser();</script>"; //arroja un mensaje de error si el usuario no existe.
    }
  }

?>