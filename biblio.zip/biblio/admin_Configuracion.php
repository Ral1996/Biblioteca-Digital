<?php

//Invocamos la SESSION.
session_start();
// Incluimos los archivos de CONEXIÓN.
include_once("db.php");
include_once("conexion.php");

if(!isset($_SESSION["Admin"])) // Sí la sesión es diferente de "Admin" se le redireccionará a el LOGIN.
{
    echo "<script>location.replace('index.php');</script>";
}
    

?>

<!DOCTYPE html>
<html class="no-js" lang="es">
<head>
    <?php include "head.php"; ?>
</head>
<body>

    <?php include "left_menu.php"; ?>
    
    <!-- Right Panel -->

    <div id="right-panel" class="right-panel">

        <?php include "top_menu.php"; ?>
        
        <div class="content mt-3"> <!-- .content -->

            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-inverse panel-border">
                        <div class="panel-heading">
                            <!--<h3 class="panel-title">Administrar Departamentos</h3>-->
                        </div>
                        <div class="panel-body">
                            <a class="btn btn-success" href="add_User.php"><i class="fa fa-plus-square"></i> Agregar usuario</a>
                            <br>
                            <?php
                                if($_SESSION["Admin"] == "Admin")
                                {
                                    $quey_users = mysqli_query($con,"SELECT * FROM usuarios") or die(mysqli_error());       
                            ?>
                            <br>
                            <div class="col-md-12">
                               
                                <table class="table table-striped table-bordered" >
                                    <thead>
                                        <tr class="table-success">
                                            <th class="col-sm-1">N°</th>
                                            <th style="width: 20%;">Nombre</th>
                                            <th class="">Correo</th>
                                            <th class="">Cargo</th>
                                            <th class="">Usuario</th>
                                            <th class="">Estado</th>
                                            <th class="">Acciones</th>
                                        </tr>
                                    </thead>
                                    <tbody>

                                    <?php
                                        
                                        $i=1;
                                        while ($row = mysqli_fetch_array($quey_users))
                                        {
                                            $id = $row['id_usu']; 
                                            $activo = $row['activo_user'];
                                    ?>
                                    <tr>   
                                        <td><?php echo $i;?></td>
                                        <td><?php echo $row['name_usu'];?></td>
                                        <td><?php echo $row['email_usu'];?></td>
                                        <td><?php echo $row['cargo_usu'];?></td>
                                        <td><?php echo $row['name_user'];?></td>
                                        
                                        <?php 
                                            if($row['activo_user'] == "ACTIVO")
                                            {
                                                echo "<td><font color='green'>".$activo."</font></td>";
                                            }else if($row['activo_user'] == "INACTIVO")
                                            {
                                                echo "<td><font color='red'>".$activo."</font></td>";
                                            }else if($row['activo_user'] == "VETADO")
                                            {
                                                echo "<td><font color='purple'>".$activo."</font></td>";
                                            }else
                                            {
                                                echo "<td>".$activo."</td>";
                                            }
                                        ?>
                                        <td class="">
                                           <a class="btn" data-toggle ='modal' data-target = "#viewModalI" data-refresh = "true" title = "Editar Usuario" href="edit_user_modal.php?id_usu=<?php echo $id;?>"><i class="fa fa-pencil"></i></a>

                                            <a class="btn" data-toggle ='modal' data-target = "#viewModalH" data-refresh = "true"  href="delete_user_modal.php?id_usu=<?php echo $id;?>" id="" title="Eliminar Usuario"><i class="fa fa-trash"></i></a>

                                            <a class="btn" data-toggle ='modal' data-target = "#viewModalG" data-refresh = "true"  href="info_user_modal.php?id_usu=<?php echo $id;?>" id="" title="Ver Información"><i class="fa fa-eye"></i></a>
                                                </ul>
                                            </div>
                                        </td>
                                        
                                    </tr>
                                    <?php
                                        $i = $i+1;
                                        } 
                                    ?>
                                    </tbody>
                                </table> 
                            
                            </div>
                            <?php
                                }
                                else
                                {
                                    echo "<br><br><div class='alert alert-danger'>No posee permisos para este modulo</div>";
                                }
                            ?>
                        </div>
                    </div>
                </div>
            </div>

            <!--Show Modal Popups View & Delete -->
            <div class='modal fade bd-example-modal-lg' id='viewModalI' tabindex='-1' role='dialog' aria-labelledby='myModalLabel' aria-hidden='true'>
                <div class='modal-dialog modal-lg'>
                    <div class='modal-content'></div><!-- /.modal-content -->
                </div><!-- /.modal-dialog -->
            </div><!-- /.modal -->  
            <!--Show Modal Popups View & Edit -->
            <div class='modal fade' id='viewModalH' tabindex='-1' role='dialog' aria-labelledby='myModalLabel' aria-hidden='true'>
                <div class='modal-dialog'>
                    <div class='modal-content modal-lg'></div><!-- /.modal-content -->
                </div><!-- /.modal-dialog -->
            </div><!-- /.modal -->  
            <!--Show Modal Popups View & Edit -->
            <div class='modal fade' id='viewModalG' tabindex='-1' role='dialog' aria-labelledby='myModalLabel' aria-hidden='true'>
                <div class='modal-dialog'>
                    <div class='modal-content modal-lg'></div><!-- /.modal-content -->
                </div><!-- /.modal-dialog -->
            </div><!-- /.modal -->  


        </div> <!-- .content -->
    </div><!-- End right-panel -->

    <!-- End Right Panel -->

    <?php include "scripts.php"; ?>
    <script type="text/javascript">
    
        $(".table").DataTable(
            {
            "iDisplayLength": 5 ,
            "language":{
                "sProcessing":     "Procesando...",
                "sLengthMenu":     "Mostrar _MENU_ registros",
                "sZeroRecords":    "No se encontraron resultados",
                "sEmptyTable":     "Ningún dato disponible en esta tabla",
                "sInfo":           "Mostrando registros del _START_ al _END_ de un total de _TOTAL_ registros",
                "sInfoEmpty":      "Mostrando registros del 0 al 0 de un total de 0 registros",
                "sInfoFiltered":   "(filtrado de un total de _MAX_ registros)",
                "sInfoPostFix":    "",
                "sSearch":         "Buscar:",
                "sUrl":            "",
                "sInfoThousands":  ",",
                "sLoadingRecords": "Cargando...",
                "oPaginate": {
                    "sFirst":    "Primero",
                    "sLast":     "Último",
                    "sNext":     "Siguiente",
                    "sPrevious": "Anterior"
                },
                "oAria": {
                    "sSortAscending":  ": Activar para ordenar la columna de manera ascendente",
                    "sSortDescending": ": Activar para ordenar la columna de manera descendente"
                }
            }
        });
    
    </script>
    <script type="text/javascript">
    $(document).on('hidden.bs.modal', function(e) 
    {
        var target = $(e.target);
        target.removeData('bs.modal').find(".modal-content").html('');
    });
    </script>
    </body>
</html>

