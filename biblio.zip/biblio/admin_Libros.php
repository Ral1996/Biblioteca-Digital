<?php

//Invocamos la SESSION.
session_start();
if(!isset($_SESSION["Admin"])) // Sí la sesión es diferente de "Admin" se le redireccionará a el LOGIN.
{
    echo "<script>location.replace('index.php');</script>";
}
// Incluimos los archivos de CONEXIÓN.
include_once("db.php");
include_once("conexion.php"); 

?>

<!DOCTYPE html>
<html class="no-js" lang="es">
<head>
    <?php include "head.php"; ?>
</head>
<body>

    <?php include "left_menu.php"; ?>
    
    <!-- Right Panel -->

    <div id="right-panel" class="right-panel">

        <?php include "top_menu.php"; ?>

        <div class="content mt-3"> <!-- .content -->

            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-inverse panel-border">
                        <div class="panel-heading">
                            <!--<h3 class="panel-title">Administrar Departamentos</h3>-->
                        </div>
                        <div class="panel-body">
                            <a class="btn btn-success" href="add_Libro.php"><i class="fa fa-plus-square"></i> Agregar libro</a>
                            <br>
                            <?php
                                if($_SESSION["Admin"] == "Admin" || $_SESSION["Admin"] == "Personal_Admin")
                                {
                                    $query_libro = mysqli_query($con,"SELECT * FROM libros ORDER BY id_book")or die(mysqli_error());
                            ?>
                            <br>
                            <div class="col-md-12">
                               
                                <table class="table table-striped table-bordered" >
                                    <thead>
                                        <tr class="table-success">
                                            <th>N°</th>                                 
                                            <th style="width: 30%;">Libro</th>                                 
                                            <th>Categoría</th>
                                            <th>Autor</th>
                                            <!--<th>Publicadora</th>-->
                                            <th>Editorial</th>
                                            <th style="width: 15%;">Acción</th>  
                                        </tr>
                                    </thead>
                                    <tbody>

                                    <?php
                                        
                                        $i=1;

                                        while ($row = mysqli_fetch_array($query_libro))
                                        {
                                            $id = $row['id_book'];  
                                            $nameBook = $row["name_book"];
                                            $cat_id = $row['category_id'];
                                            $edit_id = $row['editorial_id'];
                                            $depa_id = $row['depa_id'];
                                            $book_copies = $row['copys_book'];
                                            $autorBook = $row['name_author']; 
                                            $pubBook = $row["book_pub"];
                                            $isbnBook = $row["isbn"];
                                            $yearBook = $row["copy_year"];
                                            //$dateR_Book = $row['date_receive']; 
                                            $dateA_Book = $row["date_added"];
                                            $activo = $row['status_book'];
                                            
                                            $prestamos_details = mysqli_query($con,"SELECT * FROM prestamos_detalles WHERE book_id = '$id' AND prestamo_status = 'PENDING'");
                                            $row11 = mysqli_fetch_array($prestamos_details);
                                            $count = mysqli_num_rows($prestamos_details);
                                            
                                            $total =  $book_copies  -  $count; 
                                            
                                            $cat_query = mysqli_query($con,"SELECT * FROM categorias WHERE id_category = '$cat_id'")or die(mysqli_error());
                                            $cat_row = mysqli_fetch_array($cat_query);

                                            $edi_query = mysqli_query($con,"SELECT * FROM editoriales WHERE id_editorial = '$edit_id'") or die(mysqli_error());
                                            $edit_row = mysqli_fetch_array($edi_query);

                                            $depa_query = mysqli_query($con,"SELECT * FROM departamentos WHERE      id_department = '$depa_id'") or die(mysqli_error());
                                            $depa_row = mysqli_fetch_array($depa_query);

                                                
                                    ?>
                                    <tr>   
                                        <td><?php echo $i;?></td>
                                        <td><?php echo $nameBook;?></td>
                                        <td><?php echo $cat_row['name_category'];?></td>
                                        <td><?php echo $autorBook;?></td>
                                        <td><?php echo $edit_row['name_editorial'];?></td>
                                       
                                        <?php 
                                            /*if($row['status_book'] == "ACTIVO")
                                            {
                                                echo "<td><font color='green'>".$activo."</font></td>";
                                            }else if($row['status_book'] == "INACTIVO")
                                            {
                                                echo "<td><font color='red'>".$activo."</font></td>";
                                            }else
                                            {
                                                echo "<td>".$activo."</td>";
                                            }*/
                                        ?>
                                        
                                        <td>
                                            <a class="btn" data-toggle ='modal' data-target = "#viewModalO" data-refresh = "true" title = "Editar Libro" href="edit_book_modal.php?id_book=<?php echo $id;?>"><i class="fa fa-pencil"></i></a>
                                            <?php if($_SESSION["Admin"] == "Admin"){ ?>
                                            <a class="btn" data-toggle ='modal' data-target = "#viewModalN" data-refresh = "true"  href="delete_book_modal.php?id_book=<?php echo $id;?>" id="" title="Eliminar Libro"><i class="fa fa-trash"></i></a>
                                            <?php } ?>
                                            <a class="btn" data-toggle ='modal' data-target = "#viewModalM" data-refresh = "true"  href="info_book_modal.php?id_book=<?php echo $id;?>" id="" title="Ver Información"><i class="fa fa-eye"></i></a>
                                        </td>
                                    </tr>
                                    <?php
                                        $i = $i+1;
                                        } 
                                    ?>
                                    </tbody>
                                </table> 
                            
                            </div>
                            <?php
                                }
                                else
                                {
                                    echo "<br><br><div class='alert alert-danger'>No posee permisos para este modulo</div>";
                                }
                            ?>
                        </div>
                    </div>
                </div>
            </div>

            <!--Show Modal Popups View & Delete -->
            <div class='modal fade bd-example-modal-lg' id='viewModalO' tabindex='-1' role='dialog' aria-labelledby='myModalLabel' aria-hidden='true'>
                <div class='modal-dialog modal-lg'>
                    <div class='modal-content'></div><!-- /.modal-content -->
                </div><!-- /.modal-dialog -->
            </div><!-- /.modal -->  
            <!--Show Modal Popups View & Edit -->
            <div class='modal fade' id='viewModalN' tabindex='-1' role='dialog' aria-labelledby='myModalLabel' aria-hidden='true'>
                <div class='modal-dialog'>
                    <div class='modal-content modal-lg'></div><!-- /.modal-content -->
                </div><!-- /.modal-dialog -->
            </div><!-- /.modal -->  
            <!--Show Modal Popups View & Edit -->
            <div class='modal fade' id='viewModalM' tabindex='-1' role='dialog' aria-labelledby='myModalLabel' aria-hidden='true'>
                <div class='modal-dialog'>
                    <div class='modal-content modal-lg'></div><!-- /.modal-content -->
                </div><!-- /.modal-dialog -->
            </div><!-- /.modal -->  

        </div> <!-- .content -->
    </div><!-- End right-panel -->

    <!-- End Right Panel -->

    <?php include "scripts.php"; ?>
    <script type="text/javascript">
    
        $(".table").DataTable(
            {
            "iDisplayLength": 3 ,
            "language":{
                "sProcessing":     "Procesando...",
                "sLengthMenu":     "Mostrar _MENU_ registros",
                "sZeroRecords":    "No se encontraron resultados",
                "sEmptyTable":     "Ningún dato disponible en esta tabla",
                "sInfo":           "Mostrando registros del _START_ al _END_ de un total de _TOTAL_ registros",
                "sInfoEmpty":      "Mostrando registros del 0 al 0 de un total de 0 registros",
                "sInfoFiltered":   "(filtrado de un total de _MAX_ registros)",
                "sInfoPostFix":    "",
                "sSearch":         "Buscar:",
                "sUrl":            "",
                "sInfoThousands":  ",",
                "sLoadingRecords": "Cargando...",
                "oPaginate": {
                    "sFirst":    "Primero",
                    "sLast":     "Último",
                    "sNext":     "Siguiente",
                    "sPrevious": "Anterior"
                },
                "oAria": {
                    "sSortAscending":  ": Activar para ordenar la columna de manera ascendente",
                    "sSortDescending": ": Activar para ordenar la columna de manera descendente"
                }
            }
        });
    
    </script>
    <script type="text/javascript">
    $(document).on('hidden.bs.modal', function(e) 
    {
        var target = $(e.target);
        target.removeData('bs.modal').find(".modal-content").html('');
    });
    </script>
</body>
</html>
