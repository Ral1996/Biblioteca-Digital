<?php

//Invocamos la SESSION.
session_start();
if(!isset($_SESSION["Admin"])) // Sí la sesión es diferente de "Admin" se le redireccionará a el LOGIN.
{
    echo "<script>location.replace('index.php');</script>";
}
// Incluimos los archivos de CONEXIÓN.
include_once("db.php");
include_once("conexion.php"); 

?>

<!DOCTYPE html>
<html class="no-js" lang="es">
<head>
    <?php include "head.php"; ?>
</head>
<body>

    <?php include "left_menu.php"; ?>
    
    <!-- Right Panel -->

    <div id="right-panel" class="right-panel">

        <?php include "top_menu.php"; ?>

        <div class="content mt-3"> <!-- .content -->

            
                <center><h3>Panel de Operaciones - Digital Library</h3></center>
            <br>
            <?php
                if($_SESSION["Admin"] == "Personal_Admin")
                {
                    include "dashboard_Personal.php";   
                }
                else if($_SESSION["Admin"] == "Admin")
                {
                    include "dashboard_Admin.php"; 
                } 
            ?>

        </div> <!-- .content -->
    </div><!-- End right-panel -->

    <!-- End Right Panel -->

    <?php include "scripts.php"; ?>

</body>
</html>
