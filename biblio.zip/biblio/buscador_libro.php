<?php
	include ("db.php");
	include ("conexion.php");
	$libro = $_REQUEST["libro"];
	$autor = $_REQUEST["autor"];
	$editorial = $_REQUEST["editorial"];
	$sql = "SELECT l.*, e.name_editorial, c.name_category FROM libros as l, editoriales as e, categorias as c WHERE l.editorial_id = e.id_editorial AND l.category_id = c.id_category ";
	if($libro != "")
	{
		$sql .= "AND l.name_book LIKE '%$libro%' ";
	}
	if($autor != "")
	{
		$sql .= "AND l.name_author LIKE '%$autor%' ";
	}
	if($editorial != "")
	{
		$sql .= "AND e.name_editorial LIKE '%$editorial%' ";
	}

	$datos = "";
	$query = mysqli_query($con, $sql);
	if(mysqli_num_rows($query) > 0)
	{
		while($row=mysqli_fetch_array($query))
		{	
			$id = $row['id_book'];  
	        $nameBook = $row["name_book"];
	        $cat = $row['name_category'];
	        $edit = $row['name_editorial'];
	        $book_copies = $row['copys_book'];
	        $autorBook = $row['name_author']; 
	        $pubBook = $row["book_pub"];
	        $isbnBook = $row["isbn"];
	        $yearBook = $row["copy_year"];
	        //$dateR_Book = $row['date_receive']; 
	        $dateA_Book = $row["date_added"];
	        $activo = $row['status_book'];
	        
	        $prestamos_details = mysqli_query($con,"SELECT * FROM prestamos_detalles WHERE book_id = '$id' AND prestamo_status = 'PENDING'");
	        $row11 = mysqli_fetch_array($prestamos_details);
	        $count = mysqli_num_rows($prestamos_details);
	        
	        $total =  $book_copies  -  $count; 

			$datos .= "<tr>
							<td class='idb'>$id</td>
							<td class='nameb'>$nameBook</td>
							<td>$cat</td>
							<td>$autorBook</td>
							<td>$total</td>
							<td>$edit</td>
							<td>$isbnBook</td>
							<td>$yearBook</td>
							<td>$dateA_Book</td>
							<td>$activo</td>
							<td><a class='btn add' id_book='$id'><i class='ti ti-check bg-success p-1 font-1xl mr-1 float-left text-light'></i></a></td>
					   </tr>";
		}
	}
	else
	{
		$datos = '<tr><td colspan="11" class="text-center"><label class="alert alert-danger">No se encontraron resultados</label></td></tr>';
	}
	echo $datos;
?>
