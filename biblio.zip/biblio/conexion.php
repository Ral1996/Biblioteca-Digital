<?php

// CREAMOS LA INTERFAZ, QUE ES UNA IMPLEMENTACIÓN DEL ADAPTADOR.
Interface SimpleConex 
{
	
}

class ConexAdaptee  //CREAMOS EL ADAPTEE.
{
	private $var;
	function __construct(ConexAdapter $obj) // CREAMOS EL CONSTRUCTOR, QUE RECIBE UN OBJETO
	{
		$this->var = $obj;
	}
	function getConexAndErrores($param, $host) //SOBRECARGA DE CONEXIÓN
	{
		if($param == "ConexAdapter")
			return $this->var->getConex($host);
		else
			return $this->var;
	}
}
class ConexAdapter implements SimpleConex // CREAMOS EL ADAPTADOR QUE IMPLEMENTA LA INTERFAZ SimpleConex.
{
	function getConex($host)
	{
		return @mysqli_connect($host, DB_USER, DB_PASS, DB_NAME); //RETORNAMOS LOS PARÁMETROS DE CONEXION
	}
}
// CLIENTE
$conex = new ConexAdapter();
$result = new ConexAdaptee($conex);

$con= $result->getConexAndErrores("ConexAdapter", "localhost");
    if(!$con){
        die("imposible conectarse: ".mysqli_error($con));
    }
    if (@mysqli_connect_errno()) {
        die("Conexión falló: ".mysqli_connect_errno()." : ". mysqli_connect_error());
	}

?>
