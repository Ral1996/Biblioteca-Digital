<?php
/* PARAMETROS PARA LA CONEXIÓN */
define('DB_HOST', 'localhost');       // DB_HOST.
define('DB_USER', 'root');            // USUARIO.
define('DB_PASS', '79896680');        // CONTRASEÑA.
define('DB_NAME', 'sysbiblioteca');   // NOMBRE DE LA BASE DE DATOS.
?>
