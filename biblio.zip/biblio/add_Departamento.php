<?php

//Invocamos la SESSION.
session_start();
if(!isset($_SESSION["Admin"])) // Sí la sesión es diferente de "Admin" se le redireccionará a el LOGIN.
{
    echo "<script>location.replace('index.php');</script>";
}
// Incluimos los archivos de CONEXIÓN.
include_once("db.php");
include_once("conexion.php"); 

?>

<!DOCTYPE html>
<html class="no-js" lang="es">
<head>
    <?php include "head.php"; ?>
</head>
<body>

    <?php include "left_menu.php"; ?>
    
    <!-- Right Panel -->

    <div id="right-panel" class="right-panel">

        <?php include "top_menu.php"; ?>
        <div class="breadcrumbs">
            <div class="col-sm-12">
                <div class="page-header float-left">
                    <div class="page-title">
                        <h1>Administrar Departamentos</h1>
                    </div>
                </div>
            </div>
        </div>

        <div class="content mt-3"> <!-- .content -->

            
            <div class="row">

              <div class="col-lg-12">
                    <div class="card">
                      <div class="card-header">
                        <strong>Agregar nuevo departamento!</strong> 
                      </div>
                      <div class="card-body card-block">
                           
                            <?php
                                if($_SESSION["Admin"] == "Admin" || $_SESSION["Admin"] == "Personal_Admin")
                                {
                                    
                            ?>
                            <form class="form-horizontal" method="POST" action="" enctype="multipart/form-data">
                                
                                <div class="form-group col-sm-8">
                                    <label class="form-control-label" for="state-success">Departamento:</label>
                                        <input type="text" class="form-control" id="nameDepa1" required name="nameDepa1" placeholder="Departamento de Ingeniería y Arquitectura">
                                </div>

                                <div class="form-group col-sm-4" id="centrar">
                                    <label class="form-control-label" for="state-success">Estado:</label>
                                        <select class="select form-control" name="estado" id="estado">
                                            <?php 
                                              $estado = array('ACTIVO','INACTIVO');
                                              $array = $estado;
                                              for ($i=0; $i<sizeof($array); $i++)
                                              {
                                                echo "<option value='$array[$i]'>". $array[$i] . "</option>";
                                              }
                                            ?>
                                        </select>
                                    
                                </div>

                                <div class="form-actions">
                                    <div class="col-sm-offset-3 col-sm-9">
                                        <button class="btn btn-icon btn-primary" type="submit" id="submit" name="submit"><i class="fa fa-lock"></i>&nbsp;Guardar</button>
                                        <a class="btn btn-success" href="admin_Administrar.php"><i class="fa fa-reply"></i> Regresar</a>
                                    </div>
                                </div>

                            </form> 
                            <?php
                                }
                                else
                                {
                                    echo "<br><br><div class='alert alert-danger'>No posee permisos para este modulo</div>";
                                }
                            ?>  
                        </div>
                    </div>
                </div>
            </div>

        </div> <!-- .content -->
    </div><!-- End right-panel -->

    <!-- End Right Panel -->

    <?php include "scripts.php"; ?>
    <!-- SweetAlert2 -->
    <script type="text/javascript" src="assets/js/sweetalert2.all.js"></script>
    <!-- Optional: include a polyfill for ES6 Promises for IE11 and Android browser -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/core-js/2.4.1/core.js"></script>


</body>
</html>

<?php 

if (isset($_POST['submit'])){

  $nameDepa = $_POST["nameDepa1"];
  $estatusDepa = $_POST['estado'];

  if ($nameDepa == "")
  {
    echo "
            <script>
                swal({
                  type: 'error',
                  title: 'Se ha producido un error!',
                  text: 'Complete el formulario!',
                })
            </script>"; 
  }
  else{

      $sql_comprueba_depa= "SELECT * FROM departamentos WHERE name_department = '$nameDepa'";
      $ejecuta_sql_depa = mysqli_query($con,$sql_comprueba_depa);
      $comprueba_depa = mysqli_num_rows($ejecuta_sql_depa);
      if($comprueba_depa == 0)
      {
          $insertar = mysqli_query($con,"INSERT INTO departamentos (id_department,name_department,activo) 
          values(null, '$nameDepa', '$estatusDepa')");
          if($insertar)
          {
              echo "
                <script>
                    swal({
                      type: 'success',
                      title: 'Acción procesada con éxito!',
                      text: 'El departamento se guardo con éxito!',
                    })
                </script>";     
                 
          }else
          {
              echo "
                <script>
                    swal({
                      type: 'error',
                      title: 'Se ha producido un error!',
                      text: 'No se pudo guardar el departamento!',
                    })
                </script>";  
          }
       }
       else
       {
           echo "
                <script>
                    swal({
                      type: 'error',
                      title: 'Se ha producido un error!',
                      text: 'El departamento ya existe!',
                    })
                </script>"; 
          // mysqli_close($con);
       }
   }     
}
?>  