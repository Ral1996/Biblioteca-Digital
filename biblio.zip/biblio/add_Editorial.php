<?php

//Invocamos la SESSION.
session_start();
if(!isset($_SESSION["Admin"])) // Sí la sesión es diferente de "Admin" se le redireccionará a el LOGIN.
{
    echo "<script>location.replace('index.php');</script>";
}
// Incluimos los archivos de CONEXIÓN.
include_once("db.php");
include_once("conexion.php"); 

?>

<!DOCTYPE html>
<html class="no-js" lang="es">
<head>
    <?php include "head.php"; ?>
</head>
<body>

    <?php include "left_menu.php"; ?>
    
    <!-- Right Panel -->

    <div id="right-panel" class="right-panel">

        <?php include "top_menu.php"; ?>
        <div class="breadcrumbs">
            <div class="col-sm-12">
                <div class="page-header float-left">
                    <div class="page-title">
                        <h1>Administrar Editoriales</h1>
                    </div>
                </div>
            </div>
        </div>

        <div class="content mt-3"> <!-- .content -->

            
            <div class="row">

              <div class="col-lg-12">
                    <div class="card">
                      <div class="card-header">
                        <strong>Agregar nueva editorial!</strong> 
                      </div>
                      <div class="card-body card-block">
                           
                            <?php
                                if($_SESSION["Admin"] == "Admin" || $_SESSION["Admin"] == "Personal_Admin")
                                {
                                    
                            ?>
                            <form class="form-horizontal" method="POST" action="" enctype="multipart/form-data">
                                
                                <div class="form-group col-sm-8">
                                    <label class="form-control-label" for="state-success">Editorial:</label>
                                        <input type="text" class="form-control" id="nameEdit1" required name="nameEdit1" placeholder="Departamento de Ingeniería y Arquitectura">
                                </div>

                                <div class="form-group col-sm-4" id="centrar">
                                    <label class="form-control-label" for="state-success">Estado:</label>
                                        <select class="select form-control" name="estado" id="estado">
                                            <?php 
                                              $estado = array('ACTIVO','INACTIVO');
                                              $array = $estado;
                                              for ($i=0; $i<sizeof($array); $i++)
                                              {
                                                echo "<option value='$array[$i]'>". $array[$i] . "</option>";
                                              }
                                            ?>
                                        </select>
                                    
                                </div>

                                <div class="form-actions">
                                    <div class="col-sm-offset-3 col-sm-9">
                                        <button class="btn btn-icon btn-primary" type="submit" id="submit" name="submit"><i class="fa fa-lock"></i>&nbsp;Guardar</button>
                                        <a class="btn btn-success" href="admin_Editoriales.php"><i class="fa fa-reply"></i> Regresar</a>
                                    </div>
                                </div>

                            </form> 
                            <?php
                                }
                                else
                                {
                                    echo "<br><br><div class='alert alert-danger'>No posee permisos para este modulo</div>";
                                }
                            ?>  
                        </div>
                    </div>
                </div>
            </div>

        </div> <!-- .content -->
    </div><!-- End right-panel -->

    <!-- End Right Panel -->

    <?php include "scripts.php"; ?>
    <!-- SweetAlert2 -->
    <script type="text/javascript" src="assets/js/sweetalert2.all.js"></script>
    <!-- Optional: include a polyfill for ES6 Promises for IE11 and Android browser -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/core-js/2.4.1/core.js"></script>


</body>
</html>

<?php 

if (isset($_POST['submit'])){

  $nameEditorial = $_POST["nameEdit1"];
  $estatusEditorial = $_POST['estado'];

  if ($nameEditorial == "")
  {
    echo "
            <script>
                swal({
                  type: 'error',
                  title: 'Se ha producido un error!',
                  text: 'Complete el formulario!',
                })
            </script>"; 
  }
  else{

      $sql_comprueba_editorial = "SELECT * FROM editoriales WHERE name_editorial = '$nameEditorial'";
      $ejecuta_sql_editorial = mysqli_query($con,$sql_comprueba_editorial);
      $comprueba_editorial = mysqli_num_rows($ejecuta_sql_editorial);
      if($comprueba_editorial == 0)
      {
          $insertar_editorial = mysqli_query($con,"INSERT INTO editoriales (id_editorial,name_editorial,activo) 
          values(null, '$nameEditorial', '$estatusEditorial')");
          if($insertar_editorial)
          {
              echo "
                <script>
                    swal({
                      type: 'success',
                      title: 'Acción procesada con éxito!',
                      text: 'La editorial se guardo con éxito!',
                    })
                </script>";     
                 
          }else
          {
              echo "
                <script>
                    swal({
                      type: 'error',
                      title: 'Se ha producido un error!',
                      text: 'No se pudo guardar la editorial!',
                    })
                </script>";  
          }
       }
       else
       {
           echo "
                <script>
                    swal({
                      type: 'error',
                      title: 'Se ha producido un error!',
                      text: 'La editorial ya existe!',
                    })
                </script>"; 
          // mysqli_close($con);
       }
   }     
}
?>  