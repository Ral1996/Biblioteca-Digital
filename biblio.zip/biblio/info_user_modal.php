<?php
// INVOCAMOS LA SESSION.
session_start();

include_once("db.php");
include_once("conexion.php");

if(!isset($_SESSION["Admin"]))
{
    echo "<script>location.replace('index.php');</script>";
}

?>
<div class="modal-header">
		<h4 class="modal-title">Detalle de Usuarios</h4>
	<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
</div>
<div class="modal-body col-lg-12">
	<?php
		if($_SESSION["Admin"] == "Admin" || $_SESSION["Admin"] == "Personal_Admin")
        {

			// CREAMOS CONSULTAS PARA MOSTRAR DATOS RELEVANTES EN LA TABLA-MODAL.    	
			$id_user = $_REQUEST['id_usu'];
			$consulta_usuarios2 = mysqli_query($con,"SELECT * FROM usuarios WHERE id_usu = '$id_user'");
			$datos = mysqli_fetch_array($consulta_usuarios2);
            $name_usuario = $datos['name_usu'];
            $direc_usuario = $datos['direc_usu'];
		    $tell_usuario = $datos['tell_usu'];
		    $email_usuario = $datos['email_usu'];
		    $cargo_usuario = $datos['cargo_usu'];
		    $namex_usuario = $datos['name_user'];
		    //$pass_usuario = $datos['pass_user'];
		    //$permiso_usuario = $datos['permiso_usu'];
		    $estatus_usuario = $datos['activo_user'];
	?>
	<div class="wrapper wrapper-content animated fadeInRight">
		<div class="row" id="row1">
			<div class="col-lg-12">

				<form class="form-horizontal" method="POST"">
                
	                <div class="form-group col-sm-12">
                    <label class="form-control-label" for="state-success">Nombre:</label>
                        <input type="text" class="form-control" id="name_usuario" name="name_usuario" placeholder="Ligth Yagami" required value="<?php echo $name_usuario; ?>" disabled>
                    </div>

                    <div class="form-group col-sm-8">
                        <label class="form-control-label" for="state-success">Dirección:</label>
                            <input type="text" class="form-control" id="direccion_user" name="direccion_user" placeholder="Los alamos, okinawa" required value="<?php echo $direc_usuario; ?>" disabled>
                    </div>

                    <div class="form-group col-sm-4">
                        <label class="form-control-label" for="state-success">Teléfono:</label>
                            <input type="text" class="form-control" id="telefono_user" name="telefono_user" placeholder="7785-9977" required value="<?php echo $tell_usuario; ?>" disabled>
                    </div>

                    <div class="form-group col-sm-8">
                        <label class="form-control-label" for="state-success">Correo:</label>
                            <input type="email" class="form-control" id="correo_user" name="correo_user" placeholder="algo_2018@gmail.com" required value="<?php echo $email_usuario; ?>" disabled>
                    </div>

                    <div class="form-group col-sm-4">
                        <label class="form-control-label" for="state-success">Usuario:</label>
                            <input type="text" class="form-control" id="name_user" name="name_user" placeholder="Bran9722" required value="<?php echo $namex_usuario; ?>" disabled>
                    </div>

                    <div class="form-group col-sm-6">
                        <label class="form-control-label" for="state-success">Cargo:</label>
                            <input type="text" class="form-control" id="cargo_user" name="cargo_user" placeholder="Auditor de Sistema" required value="<?php echo $cargo_usuario; ?>" disabled>
                    </div>

                    <div class="form-group col-sm-4">
                        <label class="form-control-label" for="state-success">Estado:</label>
                            <input type="text" class="form-control" id="name_user" name="name_user" placeholder="VETADO" required value="<?php echo $estatus_usuario; ?>" disabled>
                    </div>

                </form> 
				
			</div>
		</div>
	</div>
<!-- SweetAlert2 -->
<script type="text/javascript" src="assets/js/sweetalert2.all.js"></script>
<!-- Optional: include a polyfill for ES6 Promises for IE11 and Android browser -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/core-js/2.4.1/core.js"></script>
<script type="text/javascript">
	
// Clean the modal form
	$(document).on('hidden.bs.modal', function(e) 
	{
		var target = $(e.target);
		target.removeData('bs.modal').find(".modal-content").html('');
	});
	
</script>
			
		</div>
<div class="modal-footer">
<?php

echo "
	  <button type='button' class='btn btn-success' data-dismiss='modal' id='salir'><i class='fa fa-reply-all'></i> Salir</button>
	  
				  
</div><!--/modal-footer -->";	
		}

		else
		{
			echo "<div class='alert alert-warning'>Usted no tiene permiso para acceder a este modulo</div></div>";
		}

	
?>
