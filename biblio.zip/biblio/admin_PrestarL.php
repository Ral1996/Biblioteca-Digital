<?php

//Invocamos la SESSION.
function initial()
{
    session_start();
    if(!isset($_SESSION["Admin"])) // Sí la sesión es diferente de "Admin" se le redireccionará a el LOGIN.
    {
        echo "<script>location.replace('index.php');</script>";
    }
    // Incluimos los archivos de CONEXIÓN.
    include_once("db.php");
    include_once("conexion.php"); 
?>
<!DOCTYPE html>
<html class="no-js" lang="es">
<head>
    <?php include "head.php"; ?>
</head>
<body>

    <?php include "left_menu.php"; ?>
    
    <!-- Right Panel -->

    <div id="right-panel" class="right-panel">

        <?php include "top_menu.php"; ?>

        <div class="content mt-3"> <!-- .content -->
            <div class="col-lg-12">
                <div class="panel panel-inverse panel-border">
                    <div class="panel-heading">
                        <!--<h3 class="panel-title">Administrar Departamentos</h3>-->
                    </div>
                    <div class="panel-body">
                        <br>
                        <?php
                            if($_SESSION["Admin"] == "Admin" || $_SESSION["Admin"] == "Personal_Admin")
                            {
                          
                        ?>
                        <form method="POST" action="">
                        <div class="row">    
                            <div class="form-group col-lg-6" id="centrar">
                                <label class="form-control-label" for="state-success">Miembro:</label>
                                <input type="text" class="form-control" name="miembro" id="miembro" placeholder="Nombre del miembro">
                            </div>
                        </div>
                        <div class="row">    
                            <div class="form-group col-lg-4" id="centrar">
                                <label class="form-control-label" for="state-success">Titulo:</label>
                                <input type="text" class="form-control filter" name="titulo" id="titulo" placeholder="Titulo del Libro">
                            </div>
                            <div class="form-group col-lg-4" id="centrar">
                                <label class="form-control-label" for="state-success">Autor:</label>
                                <input type="text" class="form-control filter" name="autor" id="autor" placeholder="Nombre del autor">
                            </div>
                            <div class="form-group col-lg-4" id="centrar">
                                <label class="form-control-label" for="state-success">Editorial:</label>
                                <input type="text" class="form-control filter" name="editorial" id="editorial" placeholder="Nombre de la editorial">
                            </div>
                        </div>   
                        <div class="row"> 
                            <div class="col-md-12">
                                <h5>Disponibilidad</h5>
                                <table class="table table-striped table-bordered" >
                                    <thead>
                                        <tr class="table-success">
                                            <th>N°</th>                                 
                                            <th>Libro</th>                                 
                                            <th>Categoría</th>
                                            <th>Autor</th>
                                            <th>Copias</th>
                                            <!--<th>Publicadora</th>-->
                                            <th>Editorial</th>
                                            <th>ISBN</th>
                                            <th>Año</th>
                                            <th>Fecha</th>
                                            <th>Estado</th>
                                            <th>Acción</th>  
                                        </tr>
                                    </thead>
                                    <tbody id="appends">
                                        <tr><td colspan="11" class="text-center"><label class="alert alert-danger">No se encontraron resultados</label></td></tr>
                                    </tbody>
                                </table> 
                            </div>
                        </div>
                        <div class="row"> 
                            <div class="col-md-12">
                                <h5>Prestamo</h5>
                                <table id="appendp">
                                    
                                </table>
                            </div>
                        </div>
                        </form>
                        <div class="row">
                            <div class="col-md-12">
                                <button class="btn btn-success pull-right" id="savea">Guardar</button>
                            </div>
                        </div>
                        <?php
                            }
                            else
                            {
                                echo "<br><br><div class='alert alert-danger'>No posee permisos para este modulo</div>";
                            }
                        ?>
                    </div>
                </div>
            </div>
        </div> <!-- .content -->
    </div><!-- End right-panel -->

    <!-- End Right Panel -->

    <?php include "scripts.php"; ?>
    <script type="text/javascript" src="assets/js/sweetalert2.all.js"></script>
    <script type="text/javascript" src="assets/js/bootstrap3-typeahead.js"></script>
    <script type="text/javascript">
        $(document).ready(function(){
            $("#miembro").typeahead(
            {
                //Definimos la ruta y los parametros de la busqueda para el autocomplete
                source: function(query, process)
                {
                    $.ajax(
                    {
                        url: 'autocomplete_miembro.php',
                        type: 'GET',
                        data: 'query=' + query ,
                        dataType: 'JSON',
                        async: true,   
                        //Una vez devueltos los resultados de la busqueda, se pasan los valores al campo del formulario
                        //para ser mostrados 
                        success: function(data)
                        {     
                            process(data);
                        }
                    });                
                },
            });
            $(".filter").keyup(function(){
                if(($(this).val()).length > 4)
                {
                    var titulo = $("#titulo").val();
                    var autor = $("#autor").val();
                    var editorial = $("#editorial").val();
                    $.ajax({
                        type: "GET",
                        url: "buscador_libro.php",
                        data:"libro="+titulo+"&autor="+autor+"&editorial="+editorial,
                        success: function(datas)
                        {
                            $("#appends").html(datas);
                        }
                    });
                }
                else
                {
                    if($("#titulo").val().length > 4 || $("#autor").val().length >4 || $("#editorial").val().length > 4)
                    {

                    }
                    else
                    {
                         $("#appends").html('<tr><td colspan="11" class="text-center"><label class="alert alert-danger">No se encontraron resultados</label></td></tr>');
                    }
                }
            });
        });
        var n = 0;
        $(document).on("click", ".add",function()
        {
                var tr = $(this).parents("tr");
                var id = tr.find(".idb").text();    
                if(!exis(id))
                {
                    if(n < 3)
                    {
                        var nombre = tr.find(".nameb").text();    
                        var tr2 = "<tr iddb='"+id+"'><td>"+id+" - "+nombre+"</td><td><a class='btn remov'><i class='ti ti-trash bg-danger p-1 font-1xl mr-1 float-left text-light'></i></a></td></tr>";
                        $("#appendp").append(tr2);
                        n ++;
                    }
                    else
                    {
                        swal({
                          type: 'error',
                          title: 'Información!',
                          text: 'Ha alcanzado el maximo de prestamos!',
                        });
                    }
                }
                else
                {
                    swal({
                      type: 'error',
                      title: 'Información!',
                      text: 'El libro ya se agrego a la lista!',
                    });
                }
        });
        $(document).on("click", ".remov", function(){
            $(this).parents("tr").remove();
            n --;
        });
        function exis(id)
        {
            var exis = false;
            $("#appendp tr").each(function(){
                if($(this).attr("iddb") == id)
                {
                    exis = true;
                }
            });
            return exis;
        }
        $(document).on("click","#savea", function(){
            if($("#miembro").val() != "")
            {
                if($("#appendp tr").length >0)
                {
                    send();
                }
                else
                {
                    swal({
                      type: 'error',
                      title: 'Información!',
                      text: 'No ha agregado ningun libro!',
                    });   
                }
            }
            else
            {  
                swal({
                  type: 'error',
                  title: 'Información!',
                  text: 'Por favor seleccione un miembro!',
                });
            }
        });
        function send()
        {
            var dtmiembro = $("#miembro").val().split("|");
            var id_miembro = dtmiembro[0];
            var datos = "";
            var cuantos = 0;
            $("#appendp tr").each(function(){
                datos += $(this).attr('iddb')+","; 
                cuantos ++;
            });
            $.ajax({
                type: "POST",
                url: "admin_PrestarL.php",
                data:"process=guardar&id_miembro="+id_miembro+"&datos="+datos+"&cuantos="+cuantos,
                dataType: "JSON",
                success: function(datax)
                {
                    swal({
                      type: datax.typeinfo,
                      title: 'Información!',
                      text: datax.msg,
                    });   
                    if(datax.typeinfo == "success")
                    {
                        setInterval("location.reload();", 1000);
                    }
                }
            });
        }
    </script>
    <script type="text/javascript">
    $(document).on('hidden.bs.modal', function(e) 
    {
        var target = $(e.target);
        target.removeData('bs.modal').find(".modal-content").html('');
    });
    </script>
    <style type="text/css">
        #inline-checkbox1
        {
            margin-left: 35px;
        }
    </style>
</body>
</html>

<?php
}
function guardar()
{
    include_once("db.php");
    include_once("conexion.php"); 
    $id_miembro = $_POST["id_miembro"];
    $datos = $_POST["datos"];
    $cuantos = $_POST["cuantos"];
    $fecha = date("Y-m-d");
    mysqli_query($con, "START TRANSACTION BEGIN");
    $insert = mysqli_query($con, "INSERT INTO prestamos (id_prestamo, member_id, date_borrow, due_date) VALUES (NULL, '$id_miembro', '$fecha', '')");
    if($insert)
    {
        $id_prestamo = mysqli_insert_id($con);
        $i = 0;
        $lista = explode(",", $datos);
        for($j = 0; $j < $cuantos; $j++)
        {
            $id_libro = $lista[$j];
            $insert2 = mysqli_query($con, "INSERT INTO prestamos_detalles (id_prestamo_detalle, book_id, prestamo_id, prestamo_status, date_return) VALUES (NULL, '$id_libro', '$id_prestamo', 'PENDING', '')");
            if($insert2)
            {
                $i ++;
            }
        }
        if($i == $cuantos)
        {
            mysqli_query($con, "COMMIT");
            $datax["typeinfo"] = "success";
            $datax["msg"] = "Prestamo realizado con exito!!!";
        }
        else
        {
            mysqli_query($con , "ROLLBACK");
            $datax["typeinfo"] = "error";
            $datax["msg"] = "Prestamo no pudo ser realizado!!!";
        } 
    }
    else
    {
        mysqli_query($con , "ROLLBACK");
        $datax["typeinfo"] = "error";
        $datax["msg"] = "Prestamo no pudo ser realizado!!!";
    }
    echo json_encode($datax);
}
if(!isset($_POST["process"]))
{
    initial();
}
else
{
    switch ($_POST["process"]) 
    {
        case 'guardar':
            guardar();
            break;
        
        default:
            initial();
            break;
    }
}

?>
    