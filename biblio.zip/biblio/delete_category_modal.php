<?php
// INVOCAMOS LA SESSION.
session_start();

function initial(){  
include_once("db.php");
include_once("conexion.php");

if(!isset($_SESSION["Admin"]))
{
    echo "<script>location.replace('index.php');</script>";
}

// CREAMOS CONSULTAS PARA MOSTRAR DATOS RELEVANTES EN LA TABLA-MODAL.    	
$id_categoria = $_REQUEST['id_category'];
$sql = "SELECT * FROM categorias WHERE id_category = '$id_categoria'";
$resultado = mysqli_query($con,$sql);
$count = mysqli_num_rows($resultado);

?>
<div class="modal-header">
		<h4 class="modal-title">Detalle de Categorías</h4>
	<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
</div>
<div class="modal-body">
	<?php
		if($_SESSION["Admin"] == "Admin"){
	?>
	<div class="wrapper wrapper-content animated fadeInRight">
		<div class="row" id="row1">
			<div class="col-lg-12">
					<table	class="table table-bordered table-striped" id="tableview">
						<thead>
							<tr>
								<th class="col-md-1">Campo</th>
								<th class="col-md-1">Detalle</th>
							</tr>
						</thead>
						<tbody>	
							<?php
								if ($count > 0)
								 {
									$row = mysqli_fetch_array($resultado);
									$categoria = $row["name_category"];
								    echo"<tr><td>Categoría</td><td>".$categoria."</td></tr>";
								}	
							?>
						</tbody>
					</table>
				</div>
			</div>
		</div>
<!-- SweetAlert2 -->
<script type="text/javascript" src="assets/js/sweetalert2.all.js"></script>
<!-- Optional: include a polyfill for ES6 Promises for IE11 and Android browser -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/core-js/2.4.1/core.js"></script>
<script type="text/javascript">
	
// Clean the modal form
	$(document).on('hidden.bs.modal', function(e) 
	{
		var target = $(e.target);
		target.removeData('bs.modal').find(".modal-content").html('');
	});
	$(document).on("click","#eliminar", function(){
		var id_cate1 = $("#id_cate1").val();
		$.ajax({
			type : "POST",
			url : "delete_category_modal.php",
			data: "process=del&id="+id_cate1 ,
	        dataType: "JSON",
			success : function(datax) {
				if(datax.info == "Ok")
				{
				    swal({
                      type: 'success',
                      title: 'Acción procesada con éxito!',
                      text: 'La categoría se elimino con éxito!',
                    });
                    setInterval("location.replace('admin_Categorias.php');", 1500);
				}
				else
				{
		            swal({
                      type: 'error',
                      title: 'Se ha producido un error!',
                      text: 'La categoría no pudo eliminarse!',
                    });
             	}
			}
		});
	});
</script>
			
		</div>
<div class="modal-footer">
<?php

echo "<button type='button' class='btn btn-danger elim' id='eliminar'><i class='fa fa-times-circle-o'></i> Eliminar</button>
	  <button type='button' class='btn btn-success' data-dismiss='modal' id='salir'><i class='fa fa-reply-all'></i> Salir</button>
	  <input type='hidden' id='id_cate1' value='".$id_categoria."'>
				  
</div><!--/modal-footer -->";	
		}

		else
		{
			echo "<div class='alert alert-warning'>Usted no tiene permiso para acceder a este modulo</div></div>";
		}

	}
?>


<?php
function eliminar()
{
	include_once("db.php");
	include_once("conexion.php");

	$id = $_POST["id"];
	$delete_category = mysqli_query($con, "DELETE FROM categorias WHERE id_category = '$id'");
	if($delete_category)
	{
		$datos["info"] = "Ok";
	}	
	else
	{

		$datos["info"] = "No".mysqli_error();
	}
	echo json_encode($datos);
}
	
if(!isset($_POST['process'])){
	initial(); 
}
else
{
if(isset($_POST['process'])){	
switch ($_POST['process']) {
	case 'del':
    eliminar();
    break;	
	} 
}			
}
?>