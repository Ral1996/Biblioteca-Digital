<?php

//Invocamos la SESSION.
session_start();
if(!isset($_SESSION["Admin"])) // Sí la sesión es diferente de "Admin" se le redireccionará a el LOGIN.
{
    echo "<script>location.replace('index.php');</script>";
}
// Incluimos los archivos de CONEXIÓN.
include_once("db.php");
include_once("conexion.php"); 

?>

<!DOCTYPE html>
<html class="no-js" lang="es">
<head>
    <?php include "head.php"; ?>
</head>
<body>

    <?php include "left_menu.php"; ?>
    
    <!-- Right Panel -->

    <div id="right-panel" class="right-panel">

        <?php include "top_menu.php"; ?>


        <div class="content mt-3"> <!-- .content -->

            
            <div class="row">

              <div class="col-lg-12">
                    <div class="card">
                      <div class="card-header">
                        <strong>Agregar nueva categoría!</strong> 
                      </div>
                      <div class="card-body card-block">
                           
                            <?php
                                if($_SESSION["Admin"] == "Admin" || $_SESSION["Admin"] == "Personal_Admin")
                                {
                                    
                            ?>
                            <form class="form-horizontal" method="POST" action="" enctype="multipart/form-data">
                                
                                <div class="form-group col-sm-8" id="centrar">
                                    <label class="form-control-label" for="state-success">Categoría:</label>
                                        <input type="text" class="form-control" id="nameCate1" required name="nameCate1" placeholder="Ciencia ficción, Terror, Romance, Suspenso, Belico.">
                                </div>
                                <div class="form-group col-sm-4" id="centrar">
                                    <label class="form-control-label" for="state-success">Estado:</label>
                                        <select class="select form-control" name="estado" id="estado">
                                            <?php 
                                              $estado = array('ACTIVO','INACTIVO');
                                              $array = $estado;
                                              for ($i=0; $i<sizeof($array); $i++)
                                              {
                                                echo "<option value='$array[$i]'>". $array[$i] . "</option>";
                                              }
                                            ?>
                                        </select>
                                    
                                </div>

                                <div class="form-actions col-sm-6" id="centrar1">
                                    <div class="col-sm-offset-3 col-sm-9">
                                        <button class="btn btn-icon btn-primary" type="submit" id="submit" name="submit"><i class="fa fa-lock"></i>&nbsp;Guardar</button>
                                        <a class="btn btn-success" href="admin_Categorias.php"><i class="fa fa-reply"></i> Regresar</a>
                                    </div>
                                </div>

                            </form> 
                            <?php
                                }
                                else
                                {
                                    echo "<br><br><div class='alert alert-danger'>No posee permisos para este modulo</div>";
                                }
                            ?>  
                        </div>
                    </div>
                </div>
            </div>

        </div> <!-- .content -->
    </div><!-- End right-panel -->

    <!-- End Right Panel -->

    <?php include "scripts.php"; ?>
    <!-- SweetAlert2 -->
    <script type="text/javascript" src="assets/js/sweetalert2.all.js"></script>
    <!-- Optional: include a polyfill for ES6 Promises for IE11 and Android browser -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/core-js/2.4.1/core.js"></script>

    <style type="text/css">
    
    </style>


</body>
</html>

<?php 

if (isset($_POST['submit'])){

  $nameCate = $_POST["nameCate1"];
  $estatusCate = $_POST["estado"];

  if ($nameCate == "")
  {
    echo "
            <script>
                swal({
                  type: 'error',
                  title: 'Se ha producido un error!',
                  text: 'Complete el formulario!',
                })
            </script>"; 
  }
  else{

      $sql_comprueba_cate = "SELECT * FROM categorias WHERE name_category = '$nameCate'";
      $ejecuta_sql_cate = mysqli_query($con,$sql_comprueba_cate);
      $comprueba_cate = mysqli_num_rows($ejecuta_sql_cate);
      if($comprueba_cate == 0)
      {
          $insertar_categoria = mysqli_query($con,"INSERT INTO categorias (id_category,name_category,activo) 
          values(null, '$nameCate','$estatusCate')");
          if($insertar_categoria)
          {
              echo "
                <script>
                    swal({
                      type: 'success',
                      title: 'Acción procesada con éxito!',
                      text: 'La categoría se guardo con éxito!',
                    });
                </script>";     
                 
          }else
          {
              echo "
                <script>
                    swal({
                      type: 'error',
                      title: 'Se ha producido un error!',
                      text: 'No se pudo guardar la categoría!',
                    });
                </script>";  
          }
       }
       else
       {
           echo "
                <script>
                    swal({
                      type: 'error',
                      title: 'Se ha producido un error!',
                      text: 'La categoría ya existe!',
                    })
                </script>"; 
          // mysqli_close($con);
       }
   }     
}
?>  