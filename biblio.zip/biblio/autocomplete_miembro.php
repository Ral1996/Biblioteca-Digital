<?php
	include ("db.php");
	include ("conexion.php");
	$query = $_REQUEST["query"];
	$entrada=mysqli_query($con, "SELECT * FROM estudiantes WHERE  name_student LIKE '%$query%'");
	$datos = "";
	while($raw=mysqli_fetch_array($entrada))
		{	
			$id = $raw["id_student"];
			$nombre = $raw["name_student"];
			$datos[]= $id."| ".$nombre;
		}
		echo json_encode($datos);
?>
