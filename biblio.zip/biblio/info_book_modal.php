<?php
// INVOCAMOS LA SESSION.
session_start();

include_once("db.php");
include_once("conexion.php");

if(!isset($_SESSION["Admin"]))
{
    echo "<script>location.replace('index.php');</script>";
}

?>
<div class="modal-header">
		<h4 class="modal-title">Detalle de Libros</h4>
	<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
</div>
<div class="modal-body col-lg-12">
	<?php
		if($_SESSION["Admin"] == "Admin" || $_SESSION["Admin"] == "Personal_Admin")
        {

			// CREAMOS CONSULTAS PARA MOSTRAR DATOS RELEVANTES EN LA TABLA-MODAL.    	
			$id_bookX = $_REQUEST['id_book'];
			$consulta_libros = mysqli_query($con,"SELECT * FROM libros WHERE id_book = '$id_bookX'");
			$datos = mysqli_fetch_array($consulta_libros);
            $name_bookX = $datos['name_book'];
            $cat_id = $datos['category_id'];	//RELATIONSHIPS
            $edit_id = $datos['editorial_id'];  //RELATIONSHIPS	
            $depa_id = $datos['depa_id'];         //RELATIONSHIPS 
		    $autor_bookX = $datos['name_author'];
		    $copy_bookX = $datos['copys_book'];
		    $pub_bookX = $datos['book_pub'];
		    $isbn_bookX = $datos['isbn'];
		    $year_bookX = $datos['copy_year'];
		    $status_bookX = $datos['status_book'];

		    $cat_query = mysqli_query($con,"SELECT * FROM categorias WHERE id_category = '$cat_id'")or die(mysqli_error());
            $cat_row = mysqli_fetch_array($cat_query);

            $edi_query = mysqli_query($con,"SELECT * FROM editoriales WHERE id_editorial = '$edit_id'") or die(mysqli_error());
            $edit_row = mysqli_fetch_array($edi_query);
            $depa_query = mysqli_query($con,"SELECT * FROM departamentos WHERE id_department = '$depa_id'") or die(mysqli_error());
            $depa_row = mysqli_fetch_array($depa_query);

            $category1 = $cat_row['name_category'];
            $editorial = $edit_row['name_editorial'];
            $depax = $depa_row['name_department'];
	?>
	<div class="wrapper wrapper-content animated fadeInRight">
		<div class="row" id="row1">
			<div class="col-lg-12">

				<form class="form-horizontal" method="POST" action="" enctype="multipart/form-data">
                                
                    <div class="form-group col-sm-12">
                        <label class="form-control-label" for="state-success">Libro:</label>
                            <input type="text" class="form-control" id="name_book" name="name_book" placeholder="El viejo y el mar" required value="<?php echo $name_bookX; ?>" disabled>
                    </div>

                    <div class="form-group col-sm-6" id="centrar">
                        <label class="form-control-label" for="state-success">Categoría:</label>
                        <input type="text" class="form-control" id="cat_book" name="cat_book" placeholder="Aventura" required value="<?php echo $category1; ?>" disabled>
                    </div>

                    <div class="form-group col-sm-6">
                        <label class="form-control-label" for="state-success">Autor:</label>
                            <input type="text" class="form-control" id="autor_book" name="autor_book" placeholder="Ernest Heminway" required value="<?php echo $autor_bookX; ?>" disabled>
                    </div>

                    <div class="form-group col-sm-4">
                        <label class="form-control-label" for="state-success">N° de copias:</label>
                            <input type="text" class="form-control" id="copy_book" name="copy_book" placeholder="100" required value="<?php echo $copy_bookX; ?>" disabled>
                    </div>

                    <div class="form-group col-sm-8">
                        <label class="form-control-label" for="state-success">Publicadora:</label>
                            <input type="text" class="form-control" id="pub_book" name="pub_book" placeholder="NOVEL ENTERTEIMENT" required value="<?php echo $pub_bookX; ?>" disabled>
                    </div>

                    <div class="form-group col-sm-8" id="centrar">
                        <label class="form-control-label" for="state-success">Editorial:</label>
                        <input type="text" class="form-control" id="edit_book" name="edit_book" placeholder="NOVEL ENTERTEIMENT" required value="<?php echo $editorial; ?>" disabled>
                    </div>

                    <div class="form-group col-sm-4">
                        <label class="form-control-label" for="state-success">ISBN:</label>
                            <input type="text" class="form-control" id="isbn_book" name="isbn_book" placeholder="1-85435-628-3" required value="<?php echo $isbn_bookX; ?>" disabled>
                    </div>

                    <div class="form-group col-sm-6">
                        <label class="form-control-label" for="state-success">Año de publicación:</label>
                            <input type="text" class="form-control" id="year_book" name="year_book" placeholder="1996" required value="<?php echo $year_bookX; ?>" disabled>
                    </div>

                    <div class="form-group col-sm-6" id="centrar">
                        <label class="form-control-label" for="state-success">Estado:</label>
                        <input type="text" class="form-control" id="status_book" name="status_book" placeholder="ACTIVO" required value="<?php echo $status_bookX; ?>" disabled>
                    </div>

                    <div class="form-group col-sm-12" id="centrar">
                        <label class="form-control-label" for="state-success">Departamento en el que se localiza:</label>
                        <input type="text" class="form-control" id="depa_book" name="depa_book" placeholder="ACTIVO" required value="<?php echo $depax; ?>" disabled>
                    </div>

                </form> 
				
			</div>
		</div>
	</div>
<!-- SweetAlert2 -->
<script type="text/javascript" src="assets/js/sweetalert2.all.js"></script>
<!-- Optional: include a polyfill for ES6 Promises for IE11 and Android browser -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/core-js/2.4.1/core.js"></script>
<script type="text/javascript">
	
// Clean the modal form
	$(document).on('hidden.bs.modal', function(e) 
	{
		var target = $(e.target);
		target.removeData('bs.modal').find(".modal-content").html('');
	});

</script>
			
		</div>
<div class="modal-footer">
<?php

echo "
	  <button type='button' class='btn btn-success' data-dismiss='modal' id='salir'><i class='fa fa-reply-all'></i> Salir</button>
				  
</div><!--/modal-footer -->";	
		}

		else
		{
			echo "<div class='alert alert-warning'>Usted no tiene permiso para acceder a este modulo</div></div>";
		}

?>
