<?php
// INVOCAMOS LA SESSION.
session_start();

function initial(){  
include_once("db.php");
include_once("conexion.php");

if(!isset($_SESSION["Admin"]))
{
    echo "<script>location.replace('index.php');</script>";
}

?>
<div class="modal-header">
		<h4 class="modal-title">Detalle de Miembros</h4>
	<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
</div>
<div class="modal-body col-lg-12">
	<?php
		if($_SESSION["Admin"] == "Admin" || $_SESSION["Admin"] == "Personal_Admin")
        {

			// CREAMOS CONSULTAS PARA MOSTRAR DATOS RELEVANTES EN LA TABLA-MODAL.    	
			$id_student = $_REQUEST['id_student'];
			$consulta_Student = mysqli_query($con,"SELECT * FROM estudiantes WHERE id_student = '$id_student'");
			$datos = mysqli_fetch_array($consulta_Student);
            $name_Student = $datos["name_student"];
            //$genero_Student = $datos["genero"];
		    $correo_Student = $datos['email_student'];
		    $direccion_Student = $datos["direc_student"];
		    $telefono_Student = $datos['tell_student'];
		    //$tipo_Student = $datos["tipo"];
		    $carnet_Student = $datos['carnet_student'];
		    //$estatus_Student = $datos['estado'];
	?>
	<div class="wrapper wrapper-content animated fadeInRight">
		<div class="row" id="row1">
			<div class="col-lg-12">

				<form class="form-horizontal" method="POST"">
                
	                <div class="form-group col-sm-5">
	                    <label class="form-control-label" for="state-success">Miembro:</label>
	                        <input type="text" class="form-control" id="miembro" name="miembro" placeholder="Ligth Yagami" required value="<?php echo $name_Student; ?>">
	                </div>

	                <div class="form-group col-sm-3" id="centrar">
	                    <label class="form-control-label" for="state-success">Genero:</label>
	                        <select class="select form-control" name="genero" id="genero">
	                            <?php 
	                              $genero = array('MASCULINO','FEMENINO','OTRO');
	                              $arrayG = $genero;
	                              for ($i=0; $i<sizeof($arrayG); $i++)
	                              {
	                                echo "<option value='$arrayG[$i]'>". $arrayG[$i] . "</option>";
	                              }
	                            ?>
	                        </select>
	                    
	                </div>

	                <div class="form-group col-sm-4">
	                    <label class="form-control-label" for="state-success">Correo:</label>
	                        <input type="text" class="form-control" id="correo" name="correo" placeholder="algo_2018@gmail.com" required value="<?php echo $correo_Student; ?>">
	                </div>

	                <div class="form-group col-sm-8">
	                    <label class="form-control-label" for="state-success">Dirección:</label>
	                        <input type="text" class="form-control" id="direccion" name="direccion" placeholder="Los alamos, okinawa" required value="<?php echo $direccion_Student; ?>">
	                </div>

	                <div class="form-group col-sm-4">
	                    <label class="form-control-label" for="state-success">Teléfono:</label>
	                        <input type="text" class="form-control" id="telefono" name="telefono" placeholder="7785-9977" required value="<?php echo $telefono_Student; ?>">
	                </div>

	                <div class="form-group col-sm-4" id="centrar">
	                    <label class="form-control-label" for="state-success">Tipo:</label>
	                        <select class="select form-control" name="tipo" id="tipo">
	                            <?php 
	                              $tipo = array('DOCENTE','ESTUDIANTE');
	                              $arrayT = $tipo;
	                              for ($j=0; $j<sizeof($arrayT); $j++)
	                              {
	                                echo "<option value='$arrayT[$j]'>". $arrayT[$j] . "</option>";
	                              }
	                            ?>
	                        </select>
	                    
	                </div>

	                <div class="form-group col-sm-4">
	                    <label class="form-control-label" for="state-success">Carnet:</label>
	                        <input type="text" class="form-control" id="carnet" name="carnet" placeholder="ZM18001" required value="<?php echo $carnet_Student; ?>">
	                </div>

	                <div class="form-group col-sm-4" id="centrar">
	                    <label class="form-control-label" for="state-success">Estado:</label>
	                        <select class="select form-control" name="estado" id="estado">
	                            <?php 
	                              $estado = array('ACTIVO','INACTIVO','VETADO');
	                              $array = $estado;
	                              for ($k=0; $k<sizeof($array); $k++)
	                              {
	                                echo "<option value='$array[$k]'>". $array[$k] . "</option>";
	                              }
	                            ?>
	                        </select>
	                    
	                </div>
     
                </form> 
				
			</div>
		</div>
	</div>
<!-- SweetAlert2 -->
<script type="text/javascript" src="assets/js/sweetalert2.all.js"></script>
<!-- Optional: include a polyfill for ES6 Promises for IE11 and Android browser -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/core-js/2.4.1/core.js"></script>
<script type="text/javascript">
	
// Clean the modal form
	$(document).on('hidden.bs.modal', function(e) 
	{
		var target = $(e.target);
		target.removeData('bs.modal').find(".modal-content").html('');
	});
	$(document).on("click","#editar", function(){
		var id_estudiante1 = $("#id_student1").val();
		var nameEstu22 = $("#miembro").val();
		var genero22 = $("#genero").val();
		var direc22 = $("#direccion").val();
		var tell22 = $("#telefono").val();
		var typo22 = $("#tipo").val();
		var carnet22 = $("#carnet").val();
		var email22 = $("#correo").val();
		var estado22 = $("#estado").val();
		$.ajax({
			type : "POST",
			url : "edit_student_modal.php",
			data: "process=edit&id="+id_estudiante1+"&name="+nameEstu22+"&gen="+genero22+"&dire="+direc22+"&tel="+tell22+"&tip="+typo22+"&carne="+carnet22+"&correos="+email22+"&estatus="+estado22 ,
	        dataType: "JSON",
			success : function(datax) {
				if(datax.info == "Ok")
				{
				    swal({
                      type: 'success',
                      title: 'Acción procesada con éxito!',
                      text: 'El miembro se actualizo con éxito!',
                    });
                    setInterval("location.replace('admin_Estudiante.php');", 1500);
				}
				else
				{
		            swal({
                      type: 'error',
                      title: 'Se ha producido un error!',
                      text: 'El miembro no pudo actualizarse!',
                    });
             	}
			}
		});
	});
</script>
			
		</div>
<div class="modal-footer">
<?php

echo "<button type='button' class='btn btn-danger' id='editar'><i class='fa fa-refresh'></i> Actualizar</button>
	  <button type='button' class='btn btn-success' data-dismiss='modal' id='salir'><i class='fa fa-reply-all'></i> Salir</button>
	  <input type='hidden' id='id_student1' value='".$id_student."'>
				  
</div><!--/modal-footer -->";	
		}

		else
		{
			echo "<div class='alert alert-warning'>Usted no tiene permiso para acceder a este modulo</div></div>";
		}

	}
?>


<?php

function editar()
{
	include_once("db.php");
	include_once("conexion.php");

	$id = $_POST["id"];
	$nameEstudiante22 = $_POST["name"];
	$generoEstudiante22 = $_POST["gen"];
    $correoEstudiante22 = $_POST['correos'];
    $direccionEstudiante22 = $_POST["dire"];
    $telefonoEstudiante22 = $_POST['tel'];
    $tipoEstudiante22 = $_POST["tip"];
    $carnetEstudiante22 = $_POST['carne'];
    $estatusEstudiante22 = $_POST['estatus'];
	$edit = mysqli_query($con,
							  "UPDATE estudiantes 
							   SET name_student ='$nameEstudiante22',
							   	   gen_student ='$generoEstudiante22',
							   	   direc_student ='$direccionEstudiante22',
							   	   tell_student ='$telefonoEstudiante22',
							   	   type_student ='$tipoEstudiante22',
							   	   carnet_student ='$carnetEstudiante22',
							   	   email_student ='$correoEstudiante22',
							   	   activo = '$estatusEstudiante22' 
							   WHERE id_student = '$id'"
						);
	if($edit)
	{
		$datos["info"] = "Ok";
	}	
	else
	{

		$datos["info"] = "No".mysqli_error();
	}
	echo json_encode($datos);
}
	
if(!isset($_POST['process'])){
	initial(); 
}
else
{
if(isset($_POST['process'])){	
switch ($_POST['process']) {
	case 'edit':
    editar();
    break;	
	} 
}			
}
?>