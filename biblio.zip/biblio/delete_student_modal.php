<?php
// INVOCAMOS LA SESSION.
session_start();

function initial(){  
include_once("db.php");
include_once("conexion.php");

if(!isset($_SESSION["Admin"]))
{
    echo "<script>location.replace('index.php');</script>";
}

// CREAMOS CONSULTAS PARA MOSTRAR DATOS RELEVANTES EN LA TABLA-MODAL.    	
$id_student = $_REQUEST['id_student'];
$sql = "SELECT * FROM estudiantes WHERE id_student = '$id_student'";
$resultado = mysqli_query($con,$sql);
$count = mysqli_num_rows($resultado);

?>
<div class="modal-header">
		<h4 class="modal-title">Detalle de Miembros</h4>
	<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
</div>
<div class="modal-body">
	<?php
		if($_SESSION["Admin"] == "Admin"){
	?>
	<div class="wrapper wrapper-content animated fadeInRight">
		<div class="row" id="row1">
			<div class="col-lg-12">
					<table	class="table table-bordered table-striped" id="tableview">
						<thead>
							<tr>
								<th class="col-md-1">Campo</th>
								<th class="col-md-1">Detalle</th>
							</tr>
						</thead>
						<tbody>	
							<?php
								if ($count > 0)
								 {
									$row = mysqli_fetch_array($resultado);
									$miembro = $row["name_student"];
									$tipo = $row["type_student"];
									$carnet = $row["carnet_student"];
								    echo"<tr><td>Miembro</td><td>".$miembro."</td></tr>";
								    echo"<tr><td>Tipo</td><td>".$tipo."</td></tr>";
								    echo"<tr><td>Carnet</td><td>".$carnet."</td></tr>";
								}	
							?>
						</tbody>
					</table>
				</div>
			</div>
		</div>
<!-- SweetAlert2 -->
<script type="text/javascript" src="assets/js/sweetalert2.all.js"></script>
<!-- Optional: include a polyfill for ES6 Promises for IE11 and Android browser -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/core-js/2.4.1/core.js"></script>
<script type="text/javascript">
	
// Clean the modal form
	$(document).on('hidden.bs.modal', function(e) 
	{
		var target = $(e.target);
		target.removeData('bs.modal').find(".modal-content").html('');
	});
	$(document).on("click","#eliminar", function(){
		var id_member1 = $("#id_member1").val();
		$.ajax({
			type : "POST",
			url : "delete_student_modal.php",
			data: "process=del&id="+id_member1 ,
	        dataType: "JSON",
			success : function(datax) {
				if(datax.info == "Ok")
				{
				    swal({
                      type: 'success',
                      title: 'Acción procesada con éxito!',
                      text: 'El miembro se elimino con éxito!',
                    });
                    setInterval("location.replace('admin_Estudiante.php');", 1500);
				}
				else
				{
		            swal({
                      type: 'error',
                      title: 'Se ha producido un error!',
                      text: 'El miembro no pudo eliminarse!',
                    });
             	}
			}
		});
	});
</script>
			
		</div>
<div class="modal-footer">
<?php

echo "<button type='button' class='btn btn-danger elim' id='eliminar'><i class='fa fa-times-circle-o'></i> Eliminar</button>
	  <button type='button' class='btn btn-success' data-dismiss='modal' id='salir'><i class='fa fa-reply-all'></i> Salir</button>
	  <input type='hidden' id='id_member1' value='".$id_student."'>
				  
</div><!--/modal-footer -->";	
		}

		else
		{
			echo "<div class='alert alert-warning'>Usted no tiene permiso para acceder a este modulo</div></div>";
		}

	}
?>


<?php
function eliminar()
{
	include_once("db.php");
	include_once("conexion.php");

	$id = $_POST["id"];
	$delete_member = mysqli_query($con, "DELETE FROM estudiantes WHERE id_student = '$id'");
	if($delete_member)
	{
		$datos["info"] = "Ok";
	}	
	else
	{

		$datos["info"] = "No".mysqli_error();
	}
	echo json_encode($datos);
}
	
if(!isset($_POST['process'])){
	initial(); 
}
else
{
if(isset($_POST['process'])){	
switch ($_POST['process']) {
	case 'del':
    eliminar();
    break;	
	} 
}			
}
?>