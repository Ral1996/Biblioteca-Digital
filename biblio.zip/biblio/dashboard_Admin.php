<?php

//PARA MOSTRAR EL NÚMERO DE ADMINISTRADORES EN EXISTENCIA
$query_administradores = mysqli_query($con,"SELECT * FROM usuarios WHERE permiso_usu=1");
$total_administradores = mysqli_num_rows($query_administradores);

//PARA MOSTRAR EL NÚMERO DE PERSONAL ADMIN EN EXISTENCIA
$query_personal = mysqli_query($con,"SELECT * FROM usuarios WHERE permiso_usu =2");
$total_personal = mysqli_num_rows($query_personal);

//PARA MOSTRAR EL NÚMERO DE DEPARTAMENTOS EN EXISTENCIA
$query_departamentos = mysqli_query($con, "SELECT * FROM departamentos");
$total_departamentos = mysqli_num_rows($query_departamentos);

// PARA MOSTRAR EL NÚMERO DE CATEGORÍAS REGISTRADAS EN LA BILBLIOTECA
$query_categorias = mysqli_query($con,"SELECT * FROM categorias");
$total_categorias = mysqli_num_rows($query_categorias);

// PARA MOSTRAR EL NÚMERO DE MIEMBROS REGISTRADOS EN LA BILBLIOTECA
$query_miembros = mysqli_query($con,"SELECT * FROM estudiantes");
$total_miembros = mysqli_num_rows($query_miembros);

// PARA MOSTRAR EL NÚMERO DE EDITORIALES REGISTRADAS EN LA BILBLIOTECA
$query_editoriales = mysqli_query($con,"SELECT * FROM editoriales");
$total_editoriales = mysqli_num_rows($query_editoriales);

// PARA MOSTRAR EL NÚMERO DE EDITORIALES REGISTRADAS EN LA BILBLIOTECA
$query_libros = mysqli_query($con,"SELECT * FROM libros");
$total_libros = mysqli_num_rows($query_libros);

// PARA MOSTRAR EL NÚMERO DE PRESTAMOS
$query_prestamos = mysqli_query($con,"SELECT * FROM prestamos_detalles WHERE prestamo_status='PENDING'");
$total_prestamos = mysqli_num_rows($query_prestamos);

?>

<div class="row">

    <!-- Inicio columna 1 -->
    <div class="col-6 col-lg-3">
        <div class="card">
            <div class="card-body">
                <div class="clearfix">
                    <i class="ti ti-drupal bg-danger p-3 font-2xl mr-3 float-left text-light"></i>
                    <div class="h5 text-secondary mb-0 mt-1"><?php echo $total_administradores; ?></div>
                    <div class="text-muted text-uppercase font-weight-bold font-xs small">Administradores</div>
                </div>
                <div class="b-b-1 pt-3"></div>
                <hr>
                <div class="more-info pt-2" style="margin-bottom:-10px;">
                    <a class="font-weight-bold font-xs btn-block text-muted small" href="admin_Configuracion.php">Ver más <i class="fa fa-angle-right float-right font-lg"></i></a>
                </div>
            </div>
        </div>
    </div><!--/.col-->
    <div class="col-6 col-lg-3">
        <div class="card">
            <div class="card-body">
                <div class="clearfix">
                    <i class="ti ti-github bg-warning p-3 font-2xl mr-3 float-left text-light"></i>
                    <div class="h5 text-secondary mb-0 mt-1"><?php echo $total_personal; ?></div>
                    <div class="text-muted text-uppercase font-weight-bold font-xs small">Personal admin</div>
                </div>
                <div class="b-b-1 pt-3"></div>
                <hr>
                <div class="more-info pt-2" style="margin-bottom:-10px;">
                    <a class="font-weight-bold font-xs btn-block text-muted small" href="admin_Configuracion.php">Ver más <i class="fa fa-angle-right float-right font-lg"></i></a>
                </div>
            </div>
        </div>
    </div><!--/.col-->
    <div class="col-6 col-lg-3">
        <div class="card">
            <div class="card-body">
                <div class="clearfix">
                    <i class="ti ti-android bg-success p-3 font-2xl mr-3 float-left text-light"></i>
                    <div class="h5 text-secondary mb-0 mt-1"><?php echo $total_miembros; ?></div>
                    <div class="text-muted text-uppercase font-weight-bold font-xs small">Miembros</div>
                </div>
                <div class="b-b-1 pt-3"></div>
                <hr>
                <div class="more-info pt-2" style="margin-bottom:-10px;">
                    <a class="font-weight-bold font-xs btn-block text-muted small" href="admin_Estudiante.php">Ver más <i class="fa fa-angle-right float-right font-lg"></i></a>
                </div>
            </div>
        </div>
    </div><!--/.col-->
    <div class="col-6 col-lg-3">
        <div class="card">
            <div class="card-body">
                <div class="clearfix">
                    <i class="ti ti-home bg-info p-3 font-2xl mr-3 float-left text-light"></i>
                    <div class="h5 text-secondary mb-0 mt-1"><?php echo $total_departamentos; ?></div>
                    <div class="text-muted text-uppercase font-weight-bold font-xs small">Departamentos</div>
                </div>
                <div class="b-b-1 pt-3"></div>
                <hr>
                <div class="more-info pt-2" style="margin-bottom:-10px;">
                    <a class="font-weight-bold font-xs btn-block text-muted small" href="admin_Administrar.php">Ver más <i class="fa fa-angle-right float-right font-lg"></i></a>
                </div>
            </div>
        </div>
    </div><!--/.col-->
    <!-- Fin columna 1 -->

    <!-- Inicio columna 2 -->
        <div class="col-6 col-lg-3">
        <div class="card">
            <div class="card-body">
                <div class="clearfix">
                    <i class="ti ti-book bg-primary p-3 font-2xl mr-3 float-left text-light"></i>
                    <div class="h5 text-secondary mb-0 mt-1"><?php echo $total_libros; ?></div>
                    <div class="text-muted text-uppercase font-weight-bold font-xs small">Libros</div>
                </div>
                <div class="b-b-1 pt-3"></div>
                <hr>
                <div class="more-info pt-2" style="margin-bottom:-10px;">
                    <a class="font-weight-bold font-xs btn-block text-muted small" href="admin_Libros.php">Ver más <i class="fa fa-angle-right float-right font-lg"></i></a>
                </div>
            </div>
        </div>
    </div><!--/.col-->
    <div class="col-6 col-lg-3">
        <div class="card">
            <div class="card-body">
                <div class="clearfix">
                    <i class="ti ti-agenda bg-info p-3 font-2xl mr-3 float-left text-light"></i>
                    <div class="h5 text-secondary mb-0 mt-1"><?php echo $total_categorias; ?></div>
                    <div class="text-muted text-uppercase font-weight-bold font-xs small">Categorías</div>
                </div>
                <div class="b-b-1 pt-3"></div>
                <hr>
                <div class="more-info pt-2" style="margin-bottom:-10px;">
                    <a class="font-weight-bold font-xs btn-block text-muted small" href="admin_Categorias.php">Ver más <i class="fa fa-angle-right float-right font-lg"></i></a>
                </div>
            </div>
        </div>
    </div><!--/.col-->
    <div class="col-6 col-lg-3">
        <div class="card">
            <div class="card-body">
                <div class="clearfix">
                    <i class="ti ti-write bg-secondary p-3 font-2xl mr-3 float-left text-light"></i>
                    <div class="h5 text-secondary mb-0 mt-1"><?php echo $total_editoriales; ?></div>
                    <div class="text-muted text-uppercase font-weight-bold font-xs small">Editoriales</div>
                </div>
                <div class="b-b-1 pt-3"></div>
                <hr>
                <div class="more-info pt-2" style="margin-bottom:-10px;">
                    <a class="font-weight-bold font-xs btn-block text-muted small" href="admin_Editoriales.php">Ver más <i class="fa fa-angle-right float-right font-lg"></i></a>
                </div>
            </div>
        </div>
    </div><!--/.col-->
    <div class="col-6 col-lg-3">
        <div class="card">
            <div class="card-body">
                <div class="clearfix">
                    <i class="ti ti-bookmark-alt bg-danger p-3 font-2xl mr-3 float-left text-light"></i>
                    <div class="h5 text-secondary mb-0 mt-1"><?php echo $total_prestamos; ?></div>
                    <div class="text-muted text-uppercase font-weight-bold font-xs small">Prestamos</div>
                </div>
                <div class="b-b-1 pt-3"></div>
                <hr>
                <div class="more-info pt-2" style="margin-bottom:-10px;">
                    <a class="font-weight-bold font-xs btn-block text-muted small" href="admin_Prestamos.php">Ver más <i class="fa fa-angle-right float-right font-lg"></i></a>
                </div>
            </div>
        </div>
    </div><!--/.col-->
    <!-- Fin columna 2 -->
</div>