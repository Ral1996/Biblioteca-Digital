<?php

// INVOCAMOS LA SESSION.
session_start();

function initial(){  
include_once("db.php");
include_once("conexion.php");

if(!isset($_SESSION["Admin"]))
{
    echo "<script>location.replace('index.php');</script>";
}


?>

<!DOCTYPE html>
<html class="no-js" lang="es">
<head>
    <?php include "head.php"; ?>
</head>
<body>

    <?php include "left_menu.php"; ?>
    
    <!-- Right Panel -->

    <div id="right-panel" class="right-panel">

        <?php include "top_menu.php"; ?>

        <div class="content mt-3"> <!-- .content -->

            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-inverse panel-border">
                        <div class="panel-heading">
                            <h4 class="panel-title">Configuración Biblioteca</h4>
                        </div>
                        <div class="panel-body">
                            <?php
                                if($_SESSION["Admin"]=="Admin")
                                {
                                    $datosEmpresa = mysqli_query($con,"SELECT * FROM configuraciones WHERE id_config = '1'");
                                    $datos = mysqli_fetch_array($datosEmpresa);
                                    $id = $datos["id_config"];
                                    $nombre= $datos["name_config"];
                                    $direccion = $datos["direc_config"];
                                    $telefono = $datos["tell_config"];
                                    $correo = $datos["email_config"];
                                    $web = $datos["web_config"];
                                    //$logo = $datos["logo_config"];
                            ?>
                            <div class="col-sm-12"><br>
                                <div class="col-sm-6">
                                    <form class="form-horizontal" method="POST" action="">
                                
                                        <div class="form-group">
                                            <label class="form-control-label" for="input-small">Nombre:</label>
                                                <input type="text" class="input-small form-control-sm form-control col-sm-12" name="nameConfigx" id="nameConfig" value="<?php echo $nombre; ?>" placeholder="Biblioteca Digital, Universidad de El Salvador - FMO's">
                                        </div>
                                        <div class="form-group">
                                            <label class="form-control-label" for="state-success">Dirección:</label>
                                                <input type="text" class="input-small form-control-sm form-control col-sm-12" name="direcConfigx" id="direcConfig" value="<?php echo $direccion; ?>" placeholder="San Miguel, calle antigua a Playa el Cuco">
                                        </div>
                                        <div class="form-group">
                                            <label class="form-control-label" for="state-success">Teléfono:</label>
                                                <input type="text" class="input-small form-control-sm form-control col-sm-12" data-mask="(999) 9999-9999" class="form-control" name="tellConfigx" id="tellConfig" value="<?php echo $telefono; ?>" placeholder="(503) 7989-6677">
                                        </div>
                                        <div class="form-group">
                                            <label class="form-control-label" for="state-success">Email:</label>
                                                <input type="text" class="input-small form-control-sm form-control col-sm-12" name="emailConfigx" id="emailConfig" value="<?php echo $correo; ?>" placeholder="algo_2018@gmail.com">
                                        </div>
                                        <div class="form-group">
                                            <label class="form-control-label" for="state-success">Web site:</label>
                                                <input type="text" class="input-small form-control-sm form-control col-sm-12"  name="webConfigx" id="webConfig" value="<?php echo $web; ?>" placeholder="www.digitalLibrary.com">
                                        </div>

                                        <div class="form-actions">
                                            <div class="col-sm-12">
                                                <button class="btn btn-icon btn-block btn-primary col-sm-8" type="submit" id="btn_actualizar" name="btn_actualizar"><i class="fa fa-lock"></i>&nbsp;Actualizar</button>
                                                <a class="btn btn-success col-sm-3" href="admin_Dashboard.php"><i class="fa fa-reply"></i> Regresar</a>
                                                <?php 
                                                    echo "<input type='hidden' id='id_configuracion' value='".$id."'>";
                                                ?>
                                            </div>
                                        </div>

                                    </form> 
                                </div>
                                <div class="col-sm-6">

                                    <!-- AQUÍ COLOCAMOS EL LOGO DE LA EMPRESA -->
                                    <center>
                                        <img src="images/logoB.png" class="img-fluid img-thumbnail" id="img_logo">
                                    </center>
                                    <style type="text/css">
                                        #img_logo
                                        {
                                            width: 400px;
                                            height: 430px;
                                        }
                                    </style>
                                    
                                </div>
                            </div>
                            
                                <?php
                                    }
                                    else
                                    {
                                        echo "<br><br><div class='alert alert-danger'>No posee permisos para este modulo</div>";
                                    }

                                ?>
                        </div>
                    </div>
                </div>
            </div>
            

        </div> <!-- .content -->
    </div><!-- End right-panel -->

    <!-- End Right Panel -->

    <?php include "scripts.php"; ?>
    <!-- SweetAlert2 -->
    <script type="text/javascript" src="assets/js/sweetalert2.all.js"></script>
    <!-- Optional: include a polyfill for ES6 Promises for IE11 and Android browser -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/core-js/2.4.1/core.js"></script>
    <script type="text/javascript">
        $(document).on("click","#btn_actualizar", function(){
        var id_configuracion1 = $("#id_configuracion").val();
        var nameEmp = $("#nameConfig").val();
        var direccionEmp = $("#direcConfig").val();
        var telefonoEmp = $("#tellConfig").val();
        var emailEmp = $("#emailConfig").val();
        var webEmpresa = $("#webConfig").val();

        $.ajax({
            type : "POST",
            url : "admin_Config.php",
            data: "process=edit&id="+id_configuracion1+"&nameE="+nameEmp+"&direE="+direccionEmp+"&teleE="+telefonoEmp+"&emailE="+emailEmp+"&webE="+webEmpresa ,
            dataType: "JSON",
            success : function(datax) {
                if(datax.info == "Ok")
                {
                    swal({
                      type: 'success',
                      title: 'Acción procesada con éxito!',
                      text: 'Los datos de la bilblioteca se actualzaron con éxito!',
                    });
                    setInterval("location.replace('admin_Config.php');", 1500);
                }
                else
                {
                    swal({
                      type: 'error',
                      title: 'Se ha producido un error!',
                      text: 'Los datos de la bilblioteca no pudieron actualizarse!',
                    });
                }
            }
        });
    });
    </script>

</body>
</html>
<?php
}

function editar_Config()
{

  include_once("db.php");
  include_once("conexion.php");

  $id = $_POST["id"];
  $nombreEmpresa = $_POST["nameE"];
  $direccionEmpresa = $_POST["direE"];
  $telefonoEmpresa = $_POST["teleE"];
  $emailEmpresa = $_POST["emailE"];
  $webEmpresa = $_POST["webE"];
     
  $actualizarEmpresa = mysqli_query($con,
                                        "UPDATE configuraciones
                                            SET name_config = '$nombreEmpresa',
                                                direc_config = '$direccionEmpresa',
                                                tell_config = '$telefonoEmpresa',
                                                email_config = '$emailEmpresa',
                                                web_config = '$webEmpresa'
                                            WHERE id_config ='$id'
                                        ");
  if($actualizarEmpresa)
  {
    $datos["info"] = "Ok"; 
  }
  else
  {
    $datos["info"] = "No".mysqli_error();
  }
  echo json_encode($datos);
}

if(!isset($_POST['process'])){
    initial(); 
}
else
{
if(isset($_POST['process'])){   
switch ($_POST['process']) {
    case 'edit':
    editar_Config();
    break;  
    } 
}           
}
?>