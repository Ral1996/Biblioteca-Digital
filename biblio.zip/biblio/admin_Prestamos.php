<?php

//Invocamos la SESSION.
function initial()
{
    session_start();
    if(!isset($_SESSION["Admin"])) // Sí la sesión es diferente de "Admin" se le redireccionará a el LOGIN.
    {
        echo "<script>location.replace('index.php');</script>";
    }
    // Incluimos los archivos de CONEXIÓN.
    include_once("db.php");
    include_once("conexion.php"); 
?>
<!DOCTYPE html>
<html class="no-js" lang="es">
<head>
    <link rel="stylesheet" type="text/css" href="assets/css/sweetalert.css">
    <?php include "head.php"; ?>
</head>
<body>
    <?php include "left_menu.php"; ?>
    
    <!-- Right Panel -->

    <div id="right-panel" class="right-panel">

        <?php include "top_menu.php"; ?>

        <div class="content mt-3"> <!-- .content -->
            <div class="col-lg-12">
                <div class="panel panel-inverse panel-border">
                    <div class="panel-heading">
                        <!--<h3 class="panel-title">Administrar Departamentos</h3>-->
                    </div>
                    <div class="panel-body">
                        <br>
                        <?php
                            if($_SESSION["Admin"] == "Admin" || $_SESSION["Admin"] == "Personal_Admin")
                            {
                          
                        ?>
                        <div class="row">
                            <div class="col-lg-12">
                                <a href="admin_PrestarL.php" class="btn btn-primary"> Nuevo Prestamo</a>
                            </div>
                        </div><br>
                        <div class="row">
                            <div class="col-lg-12">
                                <table class="table table-bordered table-striped table-hover" id="table">
                                    <thead>
                                        <tr class="bg-success">
                                            <td>N°</td>
                                            <td>Miembro</td>
                                            <td>Libro</td>
                                            <td>Autor</td>
                                            <td>Editorial</td>
                                            <td>Fecha Prestamo</td>
                                            <td>Accion</td>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                            $sql = mysqli_query($con, "SELECT pd.id_prestamo_detalle, p.date_borrow, l.name_book, l.name_author, e.name_editorial, es.name_student FROM prestamos_detalles as pd, prestamos as p, libros as l, editoriales as e, estudiantes as es WHERE pd.prestamo_id=p.id_prestamo AND l.id_book=pd.book_id AND p.member_id=es.id_student AND pd.prestamo_status='PENDING' ORDER BY p.date_borrow ASC");
                                            $i = 1;
                                            while ($row = mysqli_fetch_array($sql)) 
                                            {
                                                $libro = $row["name_book"];
                                                $autor = $row["name_author"];
                                                $miembro = $row["name_student"];
                                                $editorial = $row["name_editorial"];
                                                $id_prestamo_detalle = $row["id_prestamo_detalle"];
                                                $fecha = $row["date_borrow"];
                                                echo "<tr>
                                                        <td>".$i."</td>
                                                        <td>".$miembro."</td>
                                                        <td>".$libro."</td>
                                                        <td>".$autor."</td>
                                                        <td>".$editorial."</td>
                                                        <td>".$fecha."</td>
                                                        <td><a class='btn ret' id_pd='".$id_prestamo_detalle."'><i class='ti ti-check bg-success p-1 font-1xl mr-1 float-left text-light'></i></a></td>
                                                      </tr>";
                                            }
                                        ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <?php
                            }
                            else
                            {
                                echo "<br><br><div class='alert alert-danger'>No posee permisos para este modulo</div>";
                            }
                        ?>
                    </div>
                </div>
            </div>
        </div> <!-- .content -->
    </div><!-- End right-panel -->

    <!-- End Right Panel -->

    <?php include "scripts.php"; ?>
    <script type="text/javascript" src="assets/js/sweetalert.min.js"></script>
    <script type="text/javascript" src="assets/js/bootstrap3-typeahead.js"></script>
    <script type="text/javascript">
        $("#table").DataTable(
            {
            "iDisplayLength": 5 ,
            "language":{
                "sProcessing":     "Procesando...",
                "sLengthMenu":     "Mostrar _MENU_ registros",
                "sZeroRecords":    "No se encontraron resultados",
                "sEmptyTable":     "Ningún dato disponible en esta tabla",
                "sInfo":           "Mostrando registros del _START_ al _END_ de un total de _TOTAL_ registros",
                "sInfoEmpty":      "Mostrando registros del 0 al 0 de un total de 0 registros",
                "sInfoFiltered":   "(filtrado de un total de _MAX_ registros)",
                "sInfoPostFix":    "",
                "sSearch":         "Buscar:",
                "sUrl":            "",
                "sInfoThousands":  ",",
                "sLoadingRecords": "Cargando...",
                "oPaginate": {
                    "sFirst":    "Primero",
                    "sLast":     "Último",
                    "sNext":     "Siguiente",
                    "sPrevious": "Anterior"
                },
                "oAria": {
                    "sSortAscending":  ": Activar para ordenar la columna de manera ascendente",
                    "sSortDescending": ": Activar para ordenar la columna de manera descendente"
                }
            }
        });
    </script>   
    <script type="text/javascript">
    $(document).on('click', '.ret', function() 
    {
        var id_prestamo_detalle = $(this).attr("id_pd");
        swal({
                type: 'warning',
                title: 'Desea Regresar este Libro?',
                text: 'Esta seguro de desea regresar este libro y cancelar el prestamo?',
                showCancelButton: true,
                confirmButtonText: 'Aceptar',
                confirmButtonClass: 'btn-primary',
                cancelButtonText: 'Cancelar',
                closeOnConfirm: false,
                closeOnCancel: true, 
                },
                function(isConfirm)
                {
                    if (isConfirm)
                    {
                        $.ajax({
                            type: "POST",
                            url: "admin_Prestamos.php",
                            data:"process=ret&id_prestamo_detalle="+id_prestamo_detalle,
                            dataType: "JSON",
                            success: function(datax)
                            {
                                swal({
                                  type: datax.typeinfo,
                                  title: 'Información!',
                                  text: datax.msg,
                                });   
                                if(datax.typeinfo == "success")
                                {
                                    setInterval("location.reload();", 1000);
                                }
                            }
                        });
                    } 
            });
    });
    </script>
    <style type="text/css">
        #inline-checkbox1
        {
            margin-left: 35px;
        }
    </style>
</body>
</html>

<?php
}
function retorno()
{
    include_once("db.php");
    include_once("conexion.php"); 
    $id_prestamo_detalle = $_POST["id_prestamo_detalle"];
    
    $insert2 = mysqli_query($con, "UPDATE prestamos_detalles SET prestamo_status='SUCCESS' WHERE id_prestamo_detalle='$id_prestamo_detalle'");
    if($insert2)
    {
        $datax["typeinfo"] = "success";
        $datax["msg"] = "Libro devuelto con exito!!!";
    }
    else
    {
        $datax["typeinfo"] = "error";
        $datax["msg"] = "La devolucion no pudo ser realizada!!!";
    } 
    echo json_encode($datax);
}
if(!isset($_POST["process"]))
{
    initial();
}
else
{
    switch ($_POST["process"]) 
    {
        case 'ret':
            retorno();
            break;
        
        default:
            initial();
            break;
    }
}
/*
ESTA ERA MI IDEA DE CODIGO PARA PRESTAR EL LIBRO Y GUARDAR LOS DATOS DE EL PRESTAMO Y SUS DETALLES NELSON

// Incluimos los archivos de CONEXIÓN.
include_once("db.php");
include_once("conexion.php"); 

    
$id = $_POST['selector'];
$member_id  = $_POST['tipo_member'];


if ($id == '' ){ 
    header("location: admin_PrestarL.php");
}else
{
    mysqli_query($con,"INSERT INTO prestamos (member_id,date_borrow,due_date) values ('$member_id',NOW(),NOW())")or die(mysqli_error());
    $query = mysqli_query($con,"SELECT * FROM prestamos ORDER BY id_prestamo DESC")or die(mysqli_error());
    $row = mysqli_fetch_array($query);
    $borrow_id  = $row['id_prestamo']; 
    

$N = count($id);
for($i=0; $i < $N; $i++)
{
     mysqli_query($con,"INSERT prestamos_detalles (book_id,prestamo_id,prestamo_status) values('$id[$i]','$borrow_id','PENDING')")or die(mysqli_error());

}
header("location: admin_PrestarL.php");
}  
*/
?>
    