<?php 
    session_start();
?>

<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Biblioteca Digital</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="all,follow">
    <!-- Bootstrap CSS-->
    <link rel="stylesheet" href="others/vendor/bootstrap/css/bootstrap.min.css">
    <!-- Fontastic Custom icon font-->
    <link rel="stylesheet" href="others/css/fontastic.css">
    <!-- Font Awesome CSS-->
    <link rel="stylesheet" href="others/vendor/font-awesome/css/font-awesome.min.css">
    <!-- theme stylesheet-->
    <link rel="stylesheet" href="others/css/style.default.css" id="theme-stylesheet">
    <!-- Custom stylesheet - for your changes-->
    <link rel="stylesheet" href="others/css/custom.css">
    <!-- Favicon-->
    <link rel="shortcut icon" href="favicon.png">
    <style type="text/css">
        .login-page
        {
            background: url('images/b2.jpg');
        }
    </style>
  </head>
  <body>
    <div class="page login-page">
      <div class="container d-flex align-items-center">
        <div class="form-holder has-shadow">
          <div class="row">
            <!-- Logo & Information Panel-->
            <div class="col-lg-6">
              <div class="info d-flex align-items-center">
                <div class="content">
                  <div class="logo">
                    <h1>Digital Library</h1>
                  </div>
                  <p>Bienvenidos al apartado de acceso a la Biblioteca Digital.</p>
                </div>
              </div>
            </div>
            <!-- Form Panel    -->
            <div class="col-lg-6 bg-white">
              <div class="form d-flex align-items-center">
                <div class="content">
                  <form id="login-form" method="POST">
                    <div class="form-group">
                      <input id="login-username" type="text" name="loginUsername" required class="input-material">
                      <label for="login-username" class="label-material">Usuario</label>
                    </div>
                    <div class="form-group">
                      <input id="login-password" type="password" name="loginPassword" required class="input-material">
                      <label for="login-password" class="label-material">Contraseña</label>
                    </div><button id="login" type="submit" class="btn btn-info">Aceptar</button>
                  </form><a href="#" class="forgot-pass">Olvidastes la contraseña?</a><br><!--<small>No tienes una cuenta? </small><a href="register.php" class="signup">Registrarse</a>-->
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="copyrights text-center">
        <p>Design by <a href="https://github.com/Ral1996" class="external">Raul_Soft_and_Ellen_Soft</a></p>
      </div>
    </div>
    <!-- Javascript files-->
    <script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
    <script src="others/vendor/popper.js/umd/popper.min.js"> </script>
    <script src="others/vendor/bootstrap/js/bootstrap.min.js"></script>
    <script src="others/vendor/jquery.cookie/jquery.cookie.js"> </script>
    <script src="others/vendor/jquery-validation/jquery.validate.min.js"></script>
    <script src="others/js/front.js"></script>
    <!-- SweetAlert2 -->
    <script type="text/javascript" src="assets/js/sweetalert2.all.js"></script>
    <!-- Optional: include a polyfill for ES6 Promises for IE11 and Android browser -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/core-js/2.4.1/core.js"></script>

    <!-- Función Alerta Contraseña Incorrecta --> 
    <script type="text/javascript">
        function alertaContra()
        {   
            swal({
                  type: 'error',
                  title: 'Ha sucedido un incoveniente!',
                  text: 'La contraseña que introdujo es incorrecta!',
                })
        }
        function alertaUser()
        {   
            swal({
                  type: 'error',
                  title: 'Ha sucedido un incoveniente!',
                  text: 'El usuario que introdujo es incorrecto!',
                })
        }
    </script>
  </body>
</html>

<?php
        include_once("db.php");
        include_once("conexion.php");
        include_once("check_Login.php");
?>