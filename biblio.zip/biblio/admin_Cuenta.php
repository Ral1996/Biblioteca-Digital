<?php

// INVOCAMOS LA SESSION.
session_start();

include_once("db.php");
include_once("conexion.php");

if(!isset($_SESSION["Admin"]))
{
    echo "<script>location.replace('index.php');</script>";
}


?>

<!DOCTYPE html>
<html class="no-js" lang="es">
<head>
    <?php include "head.php"; ?>
</head>
<body>

    <?php include "left_menu.php"; ?>
    
    <!-- Right Panel -->

    <div id="right-panel" class="right-panel">

        <?php include "top_menu.php"; ?>

        <div class="content mt-3"> <!-- .content -->

            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-inverse panel-border">
                        <div class="panel-heading">
                            <h4 class="panel-title">Datos del usuario!</h4>
                        </div>
                        <div class="panel-body">
                            <?php
                                if($_SESSION["Admin"] == "Admin" || $_SESSION["Admin"] == "Personal_Admin")
                                {
                                
                            ?>
                            <div class="col-sm-12"><br>
                                <div class="col-sm-6">
                                    <form class="form-horizontal" method="POST" action="">
                                
                                        <div class="form-group col-sm-12">
                                            <label class="form-control-label" for="input-small">Nombre:</label>
                                                <input type="text" class="input-small form-control-sm form-control col-sm-12" name="nameConfigx" id="nameConfig" value="<?php echo $_SESSION['name']; ?>" placeholder="Light Yagami" disabled>
                                        </div>
                                        <div class="form-group col-sm-12">
                                            <label class="form-control-label" for="state-success">Dirección:</label>
                                                <input type="text" class="input-small form-control-sm form-control col-sm-12" name="direcConfigx" id="direcConfig" value="<?php echo $_SESSION['direc']; ?>" placeholder="San Miguel, calle antigua a Playa el Cuco" disabled>
                                        </div>
                                        <div class="form-group col-lg-12">
                                            <label class="form-control-label" for="state-success">Teléfono:</label>
                                                <input type="text" class="input-small form-control-sm form-control col-sm-12" data-mask="(999) 9999-9999" class="form-control" name="tellConfigx" id="tellConfig" value="<?php echo $_SESSION['tel']; ?>" placeholder="(503) 7989-6677" disabled>
                                        </div>
                                        <div class="form-group col-sm-5">
                                            <label class="form-control-label" for="state-success">Email:</label>
                                                <input type="text" class="input-small form-control-sm form-control col-sm-12" name="emailConfigx" id="emailConfig" value="<?php echo $_SESSION['correox']; ?>" placeholder="algo_2018@gmail.com" disabled>
                                        </div>
                                        <div class="form-group col-md-3">
                                            <label class="form-control-label" for="state-success">Usuario:</label>
                                                <input type="text" class="input-small form-control-sm form-control col-sm-12"  name="webConfigx" id="webConfig" value="<?php echo $_SESSION['user']; ?>" placeholder="Kira" disabled>
                                        </div>
                                        <div class="form-group col-md-4">
                                            <label class="form-control-label" for="state-success">Cargo:</label>
                                                <input type="text" class="input-small form-control-sm form-control col-sm-12"  name="webConfigx" id="webConfig" value="<?php echo $_SESSION['cargo']; ?>" placeholder="Auditor" disabled>
                                        </div>

                                        <div class="form-actions">
                                            <div class="col-sm-12">
                                                
                                                <a class="btn btn-success btn-lg btn-block" href="admin_Dashboard.php"><i class="fa fa-reply"></i> Regresar</a>
                                                
                                            </div>
                                        </div>

                                    </form> 
                                </div>
                                <div class="col-sm-6">

                                    <!-- AQUÍ COLOCAMOS EL LOGO DE LA EMPRESA -->
                                    <center>
                                        <img src="images/people.png" class="img-fluid img-thumbnail" id="img_logo">
                                    </center>
                                    <style type="text/css">
                                        #img_logo
                                        {
                                            width: 400px;
                                            height: 430px;
                                        }
                                    </style>
                                    
                                </div>
                            </div>
                            
                                <?php
                                    }
                                    else
                                    {
                                        echo "<br><br><div class='alert alert-danger'>No posee permisos para este modulo</div>";
                                    }

                                ?>
                        </div>
                    </div>
                </div>
            </div>
            

        </div> <!-- .content -->
    </div><!-- End right-panel -->

    <!-- End Right Panel -->

    <?php include "scripts.php"; ?>
    <!-- SweetAlert2 -->
    <script type="text/javascript" src="assets/js/sweetalert2.all.js"></script>
    <!-- Optional: include a polyfill for ES6 Promises for IE11 and Android browser -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/core-js/2.4.1/core.js"></script>
    

</body>
</html>