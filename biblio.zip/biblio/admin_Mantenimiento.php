<?php

//Invocamos la SESSION.
session_start();
if(!isset($_SESSION["Admin"])) // Sí la sesión es diferente de "Admin" se le redireccionará a el LOGIN.
{
    echo "<script>location.replace('index.php');</script>";
}
// Incluimos los archivos de CONEXIÓN.
include_once("db.php");
include_once("conexion.php"); 

?>

<!DOCTYPE html>
<html class="no-js" lang="es">
<head>
    <?php include "head.php"; ?>
</head>
<body>

    <?php include "left_menu.php"; ?>
    
    <!-- Right Panel -->

    <div id="right-panel" class="right-panel">

        <?php include "top_menu.php"; ?>

        <div class="content mt-3"> <!-- .content -->
            <?php
                if($_SESSION["Admin"] == "Admin"){
            ?>
                    <div class="row">
                        <!-- Inicio columna 1 -->
                        <div class="col-6 col-lg-3">
                            <div class="card">
                                <div class="card-body">
                                    <a id="a" href="backup.php">
                                    <div class="clearfix">
                                        <i class="ti ti-reload bg-danger p-3 font-2xl mr-3 float-left text-light"></i>
                                        <div class="h5 text-secondary mb-0 mt-1"></div>
                                        <div class="text-muted text-uppercase font-weight-bold font-xs small">Crear Backup</div>
                                    </div>
                                    </a>
                                </div>
                            </div>
                        </div><!--/.col-->
                    </div>
         
            <?php
                }
                else
                {
                    echo "<div class='alert alert-danger'>Usted no tiene permiso para acceder a este modulo</div></div>";
                }
            ?>
        </div> <!-- .content -->
    </div><!-- End right-panel -->

    <!-- End Right Panel -->

    <?php include "scripts.php"; ?>
    <!-- SweetAlert2 -->
</body>
</html>
