<?php

//Invocamos la SESSION.
session_start();
if(!isset($_SESSION["Admin"])) // Sí la sesión es diferente de "Admin" se le redireccionará a el LOGIN.
{
    echo "<script>location.replace('index.php');</script>";
}
// Incluimos los archivos de CONEXIÓN.
include_once("db.php");
include_once("conexion.php"); 

?>

<!DOCTYPE html>
<html class="no-js" lang="es">
<head>
    <?php include "head.php"; ?>
</head>
<body>

    <?php include "left_menu.php"; ?>
    
    <!-- Right Panel -->

    <div id="right-panel" class="right-panel">

        <?php include "top_menu.php"; ?>

        <div class="content mt-3"> <!-- .content -->

            <!-- Contenedor primer desarrollador -->
            <div class="col-lg-4 col-md-6">
                <section class="card">
                    <div class="twt-feed blue-bg">
                        <div class="corner-ribon black-ribon">
                            <i class="fa fa-github"></i>
                        </div>
                        <div class="fa fa-github wtt-mark"></div>

                        <div class="media">
                            <a href="#">
                                <img class="align-self-center rounded-circle mr-3" style="width:85px; height:85px;" alt="" src="images/yo.jpeg">
                            </a>
                            <div class="media-body">
                                <h2 class="text-white display-6">Raúl Portillo</h2>
                                <p class="text-light">Web Developer/Designer</p>
                            </div>
                        </div>



                    </div>
                    <center>
                        <div class="weather-category twt-category">

                            <p>
                                

                            </p>


                            <p class="text-muted font-13"><strong>Nombre: </strong> <span class="m-l-15">Raul Mauricio Portillo</span></p>

                            <p class="text-muted font-13"><strong>Telefono: </strong><span class="m-l-15">(+503) 7989-6680</span></p>

                            <p class="text-muted font-13"><strong>Email :</strong><span class="m-l-15"> raul-mauricio@live.com</span></p>

                        </div>
                        
                        <footer class="twt-footer">
                            <a href="https://github.com/Ral1996"><i class="fa fa-github-square"></i></a>
                            <a href="#"><i class="fa fa-map-marker"></i></a>
                            Santiago de María, Usulútan
                        </footer>
                    </center>
                </section>
            </div>

            <div class="col-lg-4 col-md-6">
                <center>
                    <img src="images/web.png" class="img-fluid" id="img_logo">
                </center>
                <style type="text/css">
                    #img_logo
                    {
                        margin-top: 150px;
                        width: 250px;
                        height:250px;
                    }
                </style>
            </div>

            <!-- Contenedor segundo desarrollador -->
            <div class="col-lg-4 col-md-6">
                <section class="card">
                    <div class="twt-feed blue-bg">
                        <div class="corner-ribon black-ribon">
                            <i class="fa fa-github"></i>
                        </div>
                        <div class="fa fa-github wtt-mark"></div>

                        <div class="media">
                            <a href="#">
                                <img class="align-self-center rounded-circle mr-3" style="width:85px; height:85px;" alt="" src="images/ella.jpg">
                            </a>
                            <div class="media-body">
                                <h2 class="text-white display-6">Ellen Coreas</h2>
                                <p class="text-light">Web Developer/Designer</p>
                            </div>
                        </div>



                    </div>
                    <center>
                        <div class="weather-category twt-category">

                            <p>
                                
                            </p>

                            <p class="text-muted font-13"><strong>Nombre: </strong> <span class="m-l-15">Ellen Margarita Coreas </span></p>

                            <p class="text-muted font-13"><strong>Telefono: </strong><span class="m-l-15">(+503) 7398-8731</span></p>

                            <p class="text-muted font-13"><strong>Email :</strong><span class="m-l-15">ellencors@gmail.com</span></p>
                        </div>
                        
                        <footer class="twt-footer">
                            <a href="#"><i class="fa fa-github-square"></i></a>
                            <a href="#"><i class="fa fa-map-marker"></i></a>
                            San Miguel, San Miguel
                        </footer>
                    </center>
                </section>
            </div>


        </div> <!-- .content -->
    </div><!-- End right-panel -->

    <!-- End Right Panel -->

    <?php include "scripts.php"; ?>

</body>
</html>